<?php
@session_start();
if(!isset($_SESSION['SESS_login']))
{
header("location: index.php");
}
include 'comon/header.php';
include 'comon/left.php';
include 'dbconfig.php';
?>
<!-- BEGIN: Page Main-->
<div id="main">
  <div class="row">


 <?php
if (!isset($_GET['cmd']))
{
$_GET['cmd'] = "";
}
if($_GET["cmd"]=="success")
{
date_default_timezone_set('Africa/Lagos');
$dt=date("Y-m-d");
$name=$_GET['name'];
$registrationdate=$_GET['registrationdate'];
$registrationno=$_GET['registrationno'];

$address=$_GET['address'];
$phonenumber=$_GET['phonenumber'];
$email=$_GET['email'];
$useofvehicle=$_GET['useofvehicle'];
$typeofvehicle=$_GET['typeofvehicle'];
$paymentoption=$_GET['paymentoption'];
$pinnumber=$_GET['pinnumber'];
$amount=$_GET['amount'];
$duedate=$_GET['duedate'];
$chassissno=$_GET['chassissno'];
$typesofpayment=$_GET['typesofpayment'];

$date = str_replace('/', '-', $duedate );
$duedate1 = date("Y-m-d", strtotime($date));


  $sql2="INSERT INTO renewal (name,registrationdate,registrationno,address,phonenumber,email,useofvehicle,typeofvehicle,paymentoption,pinnumber,amount,duedate,chassissno,typesofpayment) 
VALUES ('$name','$registrationdate','$registrationno','$address','$phonenumber','$email','$useofvehicle','$typeofvehicle','$paymentoption','$pinnumber','$amount','$duedate1','$chassissno','$typesofpayment')";
//print_r($sql2);		   
$result2 = mysql_query($sql2);
$last_id=mysql_insert_id();

	$sql4="INSERT INTO vehiclelicensedetails (registrationdate,duedate,registrationno,paymentoption,pinnumber,amount) 
VALUES ('$registrationdate','$duedate1','$registrationno','$paymentoption','$pinnumber','$amount')";
//print_r($sql4);		   
$result4 = mysql_query($sql4);


$sql3="update preregistration set IsUsed='1' WHERE PreRegistrationNo='$registrationno'"; 	
//print_r($sql3);	
$result3 = mysql_query($sql3);
if($pinnumber!='')
{
$sql4="update generatepin set isused='1' WHERE pin='$pinnumber'"; 	
//print_r($sql3);	
$result4 = mysql_query($sql4);
}

$sql5="INSERT INTO vehiclelicense_receiptno (registrationno) 
VALUES ('$registrationno')";
$result4 = mysql_query($sql5);

?>
<script> window.open("Receipt/vehiclelicense.php?registrationno=<?php Print $registrationno;?>"); </script> 
<script> location.replace("registration.php?status=success"); </script>
 <?php
 }
if (!isset($_GET['status']))
{
$_GET['status'] = "";
}
if($_GET["status"]=="success")
{
?>

<div class="card-alert card gradient-45deg-green-teal">
    <div class="card-content white-text">
      <p>
         <i class="material-icons">check</i> Vehicle Registration Successfully........... !
      </p>
    </div>
</div>

<?php
}

?>		
    <div class="content-wrapper-before gradient-45deg-indigo-purple"></div>
    <div class="breadcrumbs-dark pb-0 pt-4" id="breadcrumbs-wrapper">
      <!-- Search for small screen-->
      <div class="container">
        
      </div>
    </div>
    <div class="col s12">
      <div class="container">
        
        <!-- Input Fields -->
        <div class="row">
          <div class="col s12">
            <div id="input-fields" class="card card-tabs">
              <div class="card-content">
                <div class="card-title">
                  <div class="row">
                    <div class="col s12 m6 l10">
                      <h4 class="card-title">RENEWAL</h4>
                    </div>
                    
                  </div>
                </div>
                <div id="view-input-fields">
                  <div class="row">
                    <div class="col s12">
                      
                      <form  method="post" action="payrenewal.php">
                        <div class="col s12">
                          <div class="col s6">
                          <div class="input-field col s12">
                            <input id="renewal" type="text" name="registrationno"  required="">
                            <label for="password">Enter Pre-Registration Number</label>
                          </div>
                        </div>
                          <div class="input-field col s6">
                            <input placeholder="Placeholder" id="date" type="date" name="registrationdate" onchange="getdate()" required="">
                            <label for="first_name1">Registration Date </label>
                          </div>
                         
                        </div>
                        
                        <div class="col s6">
                          <div class="input-field col s12">
                            <input id="name" type="text" name="name" required="" readonly="">
                            <label for="password">Name of Owner</label>
                          </div>
                        </div>
                        <div class="col s6">
                          <div class="input-field col s12">
                            <input id="phonenumber" type="text"  name="phonenumber" required="" readonly="">
                            <label for="email3">Phone No of Owner </label>
                          </div>
                        </div>
                        <div class="col s12">
                          <div class="input-field col s12">
                            <textarea id="address" name="address" required="" class="materialize-textarea" readonly=""></textarea>
                            <label for="icon_prefix2">Address of Owner</label>
                          </div>
                        </div>
                        <div class="col s6">
                          <div class="input-field col s12">
                            <input id="email" type="email" name="email" required="" readonly="">
                            <label for="password">Email</label>
                          </div>
                        </div>
                        <div class="col s6">
                          <div class="input-field col s12">
                            <input id="chassissno" type="text" required="" name="chassissno" readonly="">
                            <label for="email3">Chassiss No </label>
                          </div>
                        </div>
                        <div class="input-field col s4">
                          <select id="useofvehicle" name="useofvehicle" onchange="getdate()" required="" readonly="">
                            <option value="" disabled selected>Choose your option</option>
                           <option value="">Use of Vehicle</option>
                          <option value="Private">Private</option>
                          <option value="Commercial">Commercial</option>
                          </select>
                          <label for="last_name">Use of Vehicle</label>
                        </div>
                        <div class="input-field col s4">
                          <select id="typeofvehicle" name="typeofvehicle" required="" readonly="">
                            <option value="" disabled selected>Choose your option</option>
                           <option value="">Type of Vehicle</option>
                          <option value="Motorcycle/Tricycle">Motorcycle/Tricycle</option>
                          <option value="Car">Car</option>
                          <option value="Bus/SUV/Van">Bus/SUV/Van</option>
                          <option value="Lorry/Tipper">Lorry/Tipper</option>
                          <option value="Trucks">Trucks</option>
                          <option value="HeavyEquipment">HeavyEquipment</option>
                          </select>
                          <label for="last_name">Type of Vehicle</label>
                        </div>
                        <div class="col s4">
                          <div class="input-field col s12">
                            <input  type="text" name="duedate" id="duedate" readonly="">
                            <label for="email3">Expiry Date </label>
                          </div>
                        </div>
                        <div id="view-checkboxes">
                          <label for="payment" style="color:#6d6969;font-weight: bold;">Type of Payment</label>
                          <div class="input-field col s12">
                            <p class="mb-1">
                              <label>
                                <input class="payment" type="checkbox" data-id="1" value="Vehicle Licence" id="payment1" name="typesofpayment[]" />
                                <span>Vehicle Licence</span>
                              </label>
                            </p>
                            <p class="mb-1">
                              <label>
                                <input class="payment" type="checkbox" data-id="2" value="Road Worthiness" id="payment2" name="typesofpayment[]" />
                                <span>Road Worthiness</span>
                              </label>
                            </p>
                            <p class="mb-1">
                              <label>
                                <input class="payment" type="checkbox" data-id="3" value="Hackney Permit"  id="payment3" name="typesofpayment[]"/>
                                <span>Hackney Permit</span>
                              </label>
                            </p>
                            <p class="mb-1">
                              <label>
                                <input class="payment" type="checkbox" data-id="4" value="Insurance" id="payment4" name="typesofpayment[]" />
                                <span>Insurance </span>
                              </label>
                            </p>
                          </div>
                        </div>
                        <div class="input-field col s4">
                          <select id="paymenttype" onchange="checkFilled();" name="paymentoption" required="">
                            <option value="" disabled selected>Choose your option</option>
                              <option value="Online">Online</option>
                              <option value="PIN">PIN</option>
                          </select>
                          <label for="last_name">Payment Option</label>
                        </div>
                        <div class="col s4">
                          <div class="input-field col s12">
                            <input onblur="check_pin()" type="text" class="form-control" name="pinnumber" id="pin" 
                              placeholder="PIN Number " readonly >
                             <div style="color:red;font-size:20px;" id="uname_response" class="response"></div> 
                            <label for="email3">PIN Number  </label>
                          </div>
                        </div>
                        <div class="col s4">
                          <div class="input-field col s12">
                            <input id="amount" type="text" name="registrationfee" required="" readonly="">
                            <label for="email3">Amount </label>
                          </div>
                        </div>
                     
                  <button class="btn mb-1 waves-effect waves-light" type="submit" name="submit">Save  
                    <i class="material-icons right">send</i></button>
                       
                      </form>
                    </div>
                  </div>
                </div>
                
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="content-overlay"></div>
    </div>
  </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script> 

<script>
    $(document).ready(function() {

      $('#useofvehicle').on('change',function(){
    var useofvehicle = $(this).val();  
    var typeofvehicle=$("#typeofvehicle").val();// value in field email
    var payment_type = [];
            $.each($("input[class='payment']:checked"), function(){
                payment_type.push("'"+$(this).val()+"'");
            });
            if(payment_type.length!=0){ payment_type=payment_type}else { payment_type="'Prime'";}
    $.ajax({
     type :'GET',
        dataType:'json',
    data:{useofvehicle: useofvehicle,typeofvehicle: typeofvehicle,paymenttype:payment_type},
        url : 'codegenrate.php?useofvehicle='+useofvehicle+'&typeofvehicle='+typeofvehicle+'&paymenttype='+payment_type,
        success : function(result){
    $('#amount').val(result['fees']);
    }
   });
  }); 

  $(".payment").click(function(){
        var useofvehicle =$("#useofvehicle").val();// value in field email
        var typeofvehicle=$("#typeofvehicle").val();// value in field email
        var payment_type = [];
        $.each($("input[class='payment']:checked"), function(){
            payment_type.push("'"+$(this).val()+"'");
        });
        if(payment_type.length!=0){ payment_type=payment_type}else { payment_type="'Prime'";}
          $.ajax({
         type :'GET',
            dataType:'json',
           url : 'codegenrate.php?useofvehicle='+useofvehicle+'&typeofvehicle='+typeofvehicle+'&paymenttype='+payment_type,
            success : function(result){
            $('#amount').val(result['fees']);
            M.updateTextFields();
        }
        });
  });


  $('#typeofvehicle').on('change',function(){
  var typeofvehicle = $(this).val();  
  var useofvehicle=$("#useofvehicle").val();// value in field email
  var payment_type = [];
        $.each($("input[class='payment']:checked"), function(){
            payment_type.push("'"+$(this).val()+"'");
        });
        if(payment_type.length!=0){ payment_type=payment_type}else { payment_type="'Prime'";}
  $.ajax({
   type :'GET',
      dataType:'json',
 // data:{country_id: countryID,typeofvehicle: typeofvehicle,category:category},
     url : 'codegenrate.php?useofvehicle='+useofvehicle+'&typeofvehicle='+typeofvehicle+'&paymenttype='+payment_type,
      success : function(result){
  $('#amount').val(result['fees']);
  }

  });
  }); 


    });
</script>



<script>
$(document).ready(function(){
    $('#paymenttype').on('change',function(){
        var paymenttype = $(this).val();  
    if(paymenttype=="Online")
  {
    
    document.getElementById("pin").readOnly = true; 
  }
  else
  {
  document.getElementById("pin").readOnly = false; 
  }
    }); 
 }); 
function getdate() {
var tt1 = document.getElementById('useofvehicle').value;
if(tt1=='Private')
{
    var tt = document.getElementById('date').value;
    //alert(tt);
    var date = new Date(tt);
    var newdate = new Date(date);
    newdate.setDate(newdate.getDate() + 366);
    var dd = newdate.getDate();
    var mm = newdate.getMonth() + 1;
    var y = newdate.getFullYear();
    var someFormattedDate = dd + '/' + mm + '/' + y;
    document.getElementById('duedate').value = someFormattedDate;
    M.updateTextFields();
  //$('select').formSelect();
} 
else if(tt1=='Commercial')
{
    var tt = document.getElementById('date').value;
    var date = new Date(tt);
    var newdate = new Date(date);
    newdate.setDate(newdate.getDate() + 183);
    var dd = newdate.getDate();
    var mm = newdate.getMonth() + 1;
    var y = newdate.getFullYear();
    var someFormattedDate = dd + '/' + mm + '/' + y;
    document.getElementById('duedate').value = someFormattedDate;
}
}
</script>   
<script type="text/javascript">
function check_pin(){
var pin=$("#pin").val();// value in field email
var category='Vehicle License';
$.ajax({
    type:'post',
      url:'checkpinexists.php',// put your real file name 
        //data:{pin: pin},
    data:{pin: pin,category: category},
        success:function(msg){
    if(msg>0)
    {
     $("#uname_response").hide();
    }
    else
    {
     $("#uname_response").show();
     $("#uname_response").html("<span class='not-exists'>* PIN Not Available.</span>");
         //alert(msg); // your message will come here.  
     $('#pin').val(''); //txtID is textbox ID
    // $("#pin").focus();
    }   
        }
 });
}
</script>     
<script>
function validateForm() {
var paymentoption=document.forms["myForm"]["paymentoption"].value;
if(paymentoption=='PIN')
{
  var x = document.forms["myForm"]["pinnumber"].value;
  if (x == "") {
    alert("Please Enter PIN");
  $('#pin').val(''); //txtID is textbox ID
  //$("#pin").focus();
    return false;
  }
  }
} 
</script>  


<script type="text/javascript">
$(document).ready(function(){
    $('#renewal').on('change',function(){

        var countryID = $(this).val();  
             // alert(countryID);
    //var typeofvehicle=$("#typeofvehicle").val();// value in field email
    //alert(countryID);
    $.ajax({
     type :'POST',
        dataType:'json',
        data:'country_id='+countryID,
    //data:{country_id: countryID,typeofvehicle: typeofvehicle},
        url : 'get_data_for_Renewal.php',
        success : function(result){
       //alert(result);
    //alert(result['id']);
    // $('#amount').text(result['fees']);
    //alert ();
    $('#name').val(result['name']);
    $('#address').val(result['address']);
    $('#phonenumber').val(result['phonenumber']);
    $('#email').val(result['email']);
    $('#useofvehicle').val(result['useofvehicle']);
    $('#typeofvehicle').val(result['typeofvehicle']);
    $('#chassissno').val(result['chassissno']);
    $payment_type =(result['typesofpayment']);

    var res = $payment_type.split(",");
    jQuery.each( res, function( i, val ) {
     if(val=='Vehicle Licence'){
      $("#payment1").prop('checked',true);
     }
     if(val=='Road Worthiness'){
      $("#payment2").prop('checked',true);
     }
     if(val=='Hackney Permit'){
      $("#payment3").prop('checked',true);
     }
     if(val=='Insurance'){
      $("#payment4").prop('checked',true);
     }
});
   
        var useofvehicle =$("#useofvehicle").val();// value in field email
        var typeofvehicle=$("#typeofvehicle").val();// value in field email
        var payment_type = [];
        $.each($("input[class='payment']:checked"), function(){
            payment_type.push("'"+$(this).val()+"'");
        });
        if(payment_type.length!=0){ payment_type=payment_type}else { payment_type="'Prime'";}
          $.ajax({
         type :'GET',
            dataType:'json',
           url : 'codegenrate.php?useofvehicle='+useofvehicle+'&typeofvehicle='+typeofvehicle+'&paymenttype='+payment_type,
            success : function(result){
            $('#amount').val(result['fees']);
            M.updateTextFields();
        }
        });

   M.updateTextFields();
   $('select').formSelect();

    //$('#countrycode2').val(result['countrycode']);
    }
        
   });
    }); 
  
});

</script>
<!-- END: Page Main-->
<?php include 'comon/footer.php';?>