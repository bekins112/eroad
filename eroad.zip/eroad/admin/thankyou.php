<?php
@session_start();
if(!isset($_SESSION['SESS_login']))
{
header("location: index.php");
}
include 'comon/header.php';
include 'comon/left.php';
include 'dbconfig.php';
?>
    <div id="main">
<div class="row">


    <div class="col s12">
      <div class="card">
        <div class="card-content">
         
          <div class="row">
            <div class="col m12 s12" style="text-align: center;">
               <?php 
              
                  //echo ($RNo);exit();
                   $status= $_GET['status'] ;

                  if($status=='registration')
                {
                  
               $amount= $_GET['amount'] ;
               $pmode= $_GET['pmode'] ;
               // $registrationno= $_GET['registrationno'] ;
                  ?>
                
                <h1>Thank You!</h1>
                <p>Your payment is successful</p>
                <p>It might take up to two hours for changes to reflect</p>
                 <p>Your plate number will be ready in 12hrs</p>
               <!--  <h5>Plate Number : <span style="color: blue;"><?php echo $registrationno;?></span></h5> -->
                <h5>Amount Paid : <span style="color: blue;">NRI <?php echo $amount;?></span></h5>
                <h5>Transaction Status : <span style="color: blue;">Success</span></h5>
                <h5>Payment Vendor : <span style="color: blue;"><?php echo $pmode;?></span></h5>
                <h5>Payment Date : <span style="color: blue;"><?php echo date('d-m-Y') ?></span></h5>

                  <div class="col m5 s12">
                  </div>
                
            
                  <div class="col m2 s12">
                    <a class="btn mb-1 waves-effect waves-light" href="dashboard.php">Home</a>
                  </div>

                  <div class="col m5 s12">
                  </div>
            <?php
            }


                if($status=='registrationapprove')
                {
                  
               $amount= $_GET['amount'] ;
               $pmode= $_GET['pmode'] ;
                $registrationno= $_GET['registrationno'] ;
                  ?>
                
                <h1>Thank You!</h1>
                <p>Your payment is successful</p>
                <p>It might take up to two hours for changes to reflect</p>
                <h5>Plate Number : <span style="color: blue;"><?php echo $registrationno;?></span></h5>
                <h5>Amount Paid : <span style="color: blue;">NRI <?php echo $amount;?></span></h5>
                <h5>Transaction Status : <span style="color: blue;">Success</span></h5>
                <h5>Payment Vendor : <span style="color: blue;"><?php echo $pmode;?></span></h5>
                <h5>Payment Date : <span style="color: blue;"><?php echo date('d-m-Y') ?></span></h5>

                  <div class="col m4 s12">
                  </div>
                 <div class="col m2 s12">
                  <?php $RNo= $_GET['registrationno'] ;
                  //echo ($RNo);exit();
                  ?>
                    <a target="_blank" class="btn mb-1 waves-effect waves-light" href="Receipt/vehiclelicense.php?registrationno=<?php echo $RNo;?>">Print Receipt</a>
                  </div>
            
                  <div class="col m2 s12">
                     <a class="btn mb-1 waves-effect waves-light" href="dashboard.php">Home</a>
                  </div>

                  <div class="col m4 s12">
                  </div>
              <?php
              }
           


              if($status=='renewal')
                {
                  
               $amount= $_GET['amount'] ;
               $pmode= $_GET['pmode'] ;
                $registrationno= $_GET['registrationno'] ;
                  ?>
                <h1>Thank You!</h1>
                <p>Your payment is successful</p>
                <p>Your vehicle documents has been renewed</p>
                <h5>Plate Number : <span style="color: blue;"><?php echo $registrationno;?></span></h5>
                <h5>Amount Paid : <span style="color: blue;">NRI <?php echo $amount;?></span></h5>
                <h5>Transaction Status : <span style="color: blue;">Success</span></h5>
                <h5>Payment Vendor : <span style="color: blue;"><?php echo $pmode;?></span></h5>
                <h5>Payment Date : <span style="color: blue;"><?php echo date('d-m-Y') ?></span></h5>

                  <div class="col m4 s12">
                  </div>
                 <div class="col m2 s12">
                  <?php $RNo= $_GET['registrationno'] ;
                  //echo ($RNo);exit();
                  ?>
                    <a target="_blank" class="btn mb-1 waves-effect waves-light" href="Receipt/vehiclelicense.php?registrationno=<?php echo $RNo;?>">Print Receipt</a>
                  </div>
            
                  <div class="col m2 s12">
                     <a class="btn mb-1 waves-effect waves-light" href="dashboard.php">Home</a>
                  </div>

                  <div class="col m4 s12">
                  </div>
              <?php
              }
              ?>
            </div>
          
          </div>
          </div>
        </div>
      </div>
    </div>
  </div>


<?php include 'comon/footer.php';?>