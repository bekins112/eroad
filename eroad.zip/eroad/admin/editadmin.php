<?php
@session_start();
if(!isset($_SESSION['SESS_login']))
{
header("location: index.php");
}
include 'comon/header.php';
include 'comon/left.php';
include 'dbconfig.php';
?>
<!-- BEGIN: Page Main-->
<div id="main">
  <div class="row">
    <div class="content-wrapper-before gradient-45deg-indigo-purple"></div>
    <div class="breadcrumbs-dark pb-0 pt-4" id="breadcrumbs-wrapper">
      <!-- Search for small screen-->
      <div class="container">
  <?php

if(isset($_POST['submit'])) 
{


$sql2="update usermaster set firstname='$_POST[firstname]' 
,lastname='$_POST[lastname]',contactno='$_POST[contactno]',email='$_POST[email]',usertype='$_POST[usertype]' ,UserName='$_POST[UserName]'
 WHERE SrNo=".$_GET['id']." ";  
  
$result2 = mysql_query($sql2);
?>


<div class="card-alert card gradient-45deg-green-teal">
    <div class="card-content white-text">
      <p>
         <i class="material-icons">check</i> Admin Updated Successfully........... !
      </p>
    </div>
</div>


<?php
}
?> 
<?php
$GetPhotoSQL ="SELECT * FROM usermaster WHERE SrNo = ".$_GET['id']." LIMIT 1";
$GetPhotoResult = mysql_query($GetPhotoSQL);
$GetPhotoRow = mysql_fetch_array($GetPhotoResult);

?>
</div>
    </div>
    <div class="col s12">
      <div class="container">
        <!-- Input Fields -->
        <div class="row">
          <div class="col s12">
            <div id="input-fields" class="card card-tabs">
              <div class="card-content">
                <div class="card-title">
                  <div class="row">
                    <div class="col s12 m6 l10">
                      <h4 class="card-title">ADMIN MASTER</h4>
                    </div>
                  </div>
                </div>
                <div id="view-input-fields">
                  <div class="row">
                    <div class="col s12">
                      <form  method="post" action="">
                        <div class="col m6 s12">
                          <div class="input-field col s12">
                            <input name="firstname" id="password" type="text" required="" 
                            value="<?php echo $GetPhotoRow['firstname'];?>">
                            <label for="password">First Name</label>
                          </div>
                        </div>
                        <div class="col m6 s12">
                          <div class="input-field col s12">
                            <input name="lastname" id="password" type="text" required=""
                            value="<?php echo $GetPhotoRow['lastname'];?>">
                            <label for="password">Last Name</label>
                          </div>
                        </div>
                         <div class="col m6 s12">
                          <div class="input-field col s12">
                            <input name="contactno" id="password" type="text"
                            value="<?php echo $GetPhotoRow['contactno'];?>">
                            <label for="password">Contact No</label>
                          </div>
                        </div>
                         <div class="col m6 s12">
                          <div class="input-field col s12">
                            <input name="email" id="password" type="email"
                            value="<?php echo $GetPhotoRow['email'];?>">
                            <label for="password">Email</label>
                          </div>
                        </div>
                        <div class="col m6 s12">
                          <div class="input-field col s12">
                            <input name="UserName" id="password" type="text" required=""
                            value="<?php echo $GetPhotoRow['UserName'];?>">
                            <label for="password">Username</label>
                          </div>
                        </div>
                        
                      <div class="input-field col m6 s12">
                             <select class="custom-select form-control" id="location2" name="usertype" required="">
                  <option value="Super Admin" <?php if($GetPhotoRow['usertype'] == "Super Admin") echo "selected"; ?>>Super Admin</option>
                  <option value="Account Admin" <?php if($GetPhotoRow['usertype'] == "Account Admin") echo "selected"; ?>>Account Admin</option>
                  <option value="Admin Officers" <?php if($GetPhotoRow['usertype'] == "Admin Officers") echo "selected"; ?>>Admin Officers</option>
                  <option value="Admin Manager" <?php if($GetPhotoRow['usertype'] == "Admin Manager") echo "selected"; ?>>Admin Manager</option>
                  
                  </select>
                            <label for="last_name">Select Admin Type</label>
                          </div>
                  <button class="btn mb-1 waves-effect waves-light" type="submit" name="submit">Submit  
                    <i class="material-icons right">send</i></button>
                      </form>
                    </div>
                  </div>
                </div>
                
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="content-overlay"></div>
    </div>
  </div>
</div>
<!-- END: Page Main-->
<?php include 'comon/footer.php';?>