<?php
@session_start();
if(!isset($_SESSION['SESS_login']))
{
header("location: index.php");
}
include 'comon/header.php';
include 'comon/left.php';
include 'dbconfig.php';
?>
    <div id="main">
<div class="row">
<?php
        //////////// get_page_action and id start /////////
                if (!isset($_GET['cmd']))
                {
                $_GET['cmd'] = "";
                }
                if($_GET["cmd"]=="delete")
        {
        if (!isset($_GET['id']))
        {
        $_GET['id'] = "";
        }
        $id=$_GET['id'];
        
        
        $sql = "DELETE From preregistration WHERE id=$id";
        $result = mysql_query($sql);
    ?>
<div class="card-alert card gradient-45deg-green-teal">
    <div class="card-content white-text">
      <p>
         <i class="material-icons">check</i> Plate Number Deleted Successfully........... !
      </p>
    </div>
</div>

          <?php
                }
        //////////// get_page_action and id start /////////
?>      

    <div class="col s12">
      <div class="card">
        <div class="card-content">
          <h4 class="card-title">Manage Plate Number
          </h4>
          <div class="row">
            <div class="col s12">
              <table id="example" class="display">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Plate Number</th>
                    <th>Is Used</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                	<tr>
                		<?php
$query4="SELECT * FROM preregistration order by id DESC";
$result4=mysql_query($query4);
$num4=mysql_numrows($result4);
$iiii=0;
while ($iiii < $num4) {
$Id=mysql_result($result4,$iiii,"id");
$PreRegistrationNo=mysql_result($result4,$iiii,"PreRegistrationNo");
$IsUsed=mysql_result($result4,$iiii,"IsUsed");


?>            
                             <td><?php echo $Id; ?></td>
               <td><?php echo $PreRegistrationNo; ?></td>
               <td><?php echo $IsUsed; ?></td>
                           <td>
								<a href="editpreregistrationnumber.php?id=<?php  echo $Id; ?>&cmd=edit"> <i class="material-icons dp48">border_color</i> </a> &nbsp;&nbsp;
								  <a href="managepreregistrationnumber.php?id=<?php  echo $Id; ?>&cmd=delete" ><i class="material-icons dp48">delete</i> </a>
							</td>
                           
                        </tr>
        <?php
$iiii++;
}
?>          
                </tbody>
                <tfoot>
                  <tr>
                     <th>ID</th>
                     <th>Pre Registration Numbrer</th>
                    <th>Is Used</th>
                    <th>Action</th>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include 'comon/footer.php';?>