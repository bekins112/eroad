<?php
@session_start();
if(!isset($_SESSION['SESS_login']))
{
header("location: index.php");
}
include 'comon/header.php';
include 'comon/left.php';
include 'dbconfig.php';
?>
<!-- BEGIN: Page Main-->
<div id="main">
  <div class="row">
    <div class="content-wrapper-before gradient-45deg-indigo-purple"></div>
    <div class="breadcrumbs-dark pb-0 pt-4" id="breadcrumbs-wrapper">
      <!-- Search for small screen-->
      <div class="container">
  <?php
if(isset($_POST['submit'])) 
{
$sql2="INSERT INTO usermaster (firstname,lastname,contactno,UserName,Password,email,usertype) 
VALUES ('$_POST[firstname]','$_POST[lastname]','$_POST[contactno]','$_POST[UserName]','".md5($_POST['Password'])."','$_POST[email]','$_POST[usertype]')";
           
$result2 = mysql_query($sql2);
?>
<div class="card-alert card gradient-45deg-green-teal">
    <div class="card-content white-text">
      <p>
         <i class="material-icons">check</i> Admin Added Successfully........... !
      </p>
    </div>
</div>
<?php
}
?>        
</div>
    </div>
    <div class="col s12">
      <div class="container">
        <!-- Input Fields -->
        <div class="row">
          <div class="col s12">
            <div id="input-fields" class="card card-tabs">
              <div class="card-content">
                <div class="card-title">
                  <div class="row">
                    <div class="col s12 m6 l10">
                      <h4 class="card-title">ADMIN MASTER</h4>
                    </div>
                  </div>
                </div>
                <div id="view-input-fields">
                  <div class="row">
                    <div class="col s12">
                      <form  method="post" action="">
                        <div class="col m6 s12">
                          <div class="input-field">
                            <input name="firstname" id="password" type="text" required="">
                            <label for="password">First Name</label>
                          </div>
                        </div>
                        <div class="col m6 s12">
                          <div class="input-field">
                            <input name="lastname" id="password" type="text" required="">
                            <label for="password">Last Name</label>
                          </div>
                        </div>
                         <div class="col m6 s12">
                          <div class="input-field col s12">
                            <input name="contactno" id="password" type="text">
                            <label for="password">Contact No</label>
                          </div>
                        </div>
                         <div class="col m6 s12">
                          <div class="input-field col s12">
                            <input name="email" id="password" type="email">
                            <label for="password">Email</label>
                          </div>
                        </div>
                        <div class="col m6 s12">
                          <div class="input-field col s12">
                            <input name="UserName" id="password" type="text" required="">
                            <label for="password">Username</label>
                          </div>
                        </div>
                        <div class="col m6 s12">
                          <div class="input-field col s12">
                            <input name="Password" id="password" type="password" required="">
                            <label for="password">Password</label>
                          </div>
                        </div>
                      <div class="input-field col col m12 s12">
                            <select name="usertype" required="">
                              <option value="" disabled selected>Choose Admin Type</option>
                              <option value="Super Admin">Super Admin</option>
                              <option value="Account Admin">Account Admin</option>
                              <option value="Admin Officer">Admin Officer</option>
                              <option value="Admin Manager">Admin Manager</option>
                            </select>
                            
                            <label for="last_name">Select Admin Type</label>
                          </div>
                  <button class="btn mb-1 waves-effect waves-light" type="submit" name="submit">Submit  
                    <i class="material-icons right">send</i></button>
                      </form>
                    </div>
                  </div>
                </div>
                
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="content-overlay"></div>
    </div>
  </div>
</div>
<!-- END: Page Main-->
<?php include 'comon/footer.php';?>