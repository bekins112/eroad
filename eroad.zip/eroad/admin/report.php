<?php
@session_start();
if(!isset($_SESSION['SESS_login']))
{
header("location: index.php");
}
include 'comon/header.php';
include 'comon/left.php';
include 'dbconfig.php';
?>
<!-- BEGIN: Page Main-->
<div id="main">
  <div class="row">
    <div class="content-wrapper-before gradient-45deg-indigo-purple"></div>
    <div class="breadcrumbs-dark pb-0 pt-4" id="breadcrumbs-wrapper">
      <!-- Search for small screen-->
      <div class="container">
    
</div>
    </div>
    <div class="col s12">
      <div class="container">
        <!-- Input Fields -->
        <div class="row">
          <div class="col s12">
            <div id="input-fields" class="card card-tabs">
              <div class="card-content">
                <div class="card-title">
                  <div class="row">
                    <div class="col s12 m6 l10">
                      <h4 class="card-title">Reports</h4>
                    </div>
                  </div>
                </div>
                <div id="view-input-fields">
                  <div class="row">
                    <div class="col s12">
                      <form  method="get" action="">
                          <div class="input-field col m3 s12">
                            <input placeholder="Placeholder" id="date" type="date" name="fromdate" required="">
                            <label for="first_name1">Registration Date </label>
                          </div>
                           <div class="input-field col m3 s12">
                            <input placeholder="Placeholder" id="date" type="date" name="todate" required="">
                            <label for="first_name1">Registration Date </label>
                          </div>

                          <div class="input-field col m3 s12">
                             <select class="form-control" name="paymentmode" required>
                                <option value="">Select Payment Mode</option>
                                <option value="PIN">PIN</option>
                                <option value="Online">Online</option>
                           </select>
                            <label for="password">Select Payment Mode</label>
                          </div>

                          <div class="input-field col m3 s12">
                             <select class="form-control" name="reporttype" required>
                                <option value="">Select Report Type</option>
                                <option value="Total Revenue Generated">Total Revenue Generated</option>
                                <option value="Renewal vs registration">Renewal vs registration</option>
                                <option value="Private vs Commercial">Private vs Commercial</option>
                                <option value="Renewal based on Types of vehic">Renewal based on Types of vehic</option>
                                <option value="Expiration Based Report">Expiration Based Report</option>
                                <option value="Report Based on Payment Type">Report Based on Payment Type</option>
                           </select>
                            <label for="password">Select Report Type</label>
                          </div>
                        
                        
                     <button type="submit"  class="btn mb-1 waves-effect waves-light">Show Report 
                    <i class="material-icons right">send</i></button>
                      </form>
                    </div>
                  </div>

<?php
if (!isset($_GET['fromdate']))
{
$_GET['fromdate'] = "";
$_GET['todate'] = "";
$_GET['reporttype'] = "";
$_GET['paymentmode'] = "";
}
if($_GET["paymentmode"]!="")
{
  $paymentmode=$_GET['paymentmode'];
}
if($_GET["fromdate"]!="")
{
$fromdate=$_GET['fromdate'];
$todate=$_GET['todate'];
$reporttype=$_GET['reporttype'];
?>  

<?php if($_GET["reporttype"]="Total Revenue Generated") 
{
?>
    <div class="row">
        <div class="col s12">
      <div class="card">
        <div class="card-content">
          <h4 class="card-title"><?php echo $_GET["reporttype"];?>
          </h4>
          <div class="row">
            <div class="col s12">
              <table id="example" class="display">
                <thead>
                  <tr>
                    <th>Plate No</th>
                      <th>Name</th>
                      
                      <th>Phone Number</th>
                      <th>Email</th>
                      <th>Payment Mode</th>
                      <th>Payment Option</th>
                      <th>Fees</th>
                      <th>Date</th> 
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <?php

                    $query4="SELECT registrationno as plateno,name,phonenumber,email,'Registration' as paymentmode,paymentoption,amount as fees,registrationdate as date FROM vehiclelicense WHERE registrationdate  between '".$_GET['fromdate']."' and '".$_GET['todate']."' and paymentoption='".$_GET['paymentmode']."'
                     union all SELECT registrationno as plateno,name,phonenumber,email,'Renewal' as paymentmode,paymentoption,amount as fees,registrationdate as date FROM renewal  WHERE registrationdate  between '".$_GET['fromdate']."' and '".$_GET['todate']."' and paymentoption='".$_GET['paymentmode']."'";
/*
                     print_r($query4);
                     exit();
*/
/*$query4="SELECT r.registrationdate,v.duedate,r.registrationno,v.name,v.phonenumber,r.amount FROM registrationtypesofpayment r inner join vehiclelicense v on r.registrationno=v.registrationno 
 where v.registrationdate  between '".$_GET['fromdate']."' and '".$_GET['todate']."' and r.typesofpayment='$reporttype' order by r.id DESC";*/
$result4=mysql_query($query4);
$num4=mysql_numrows($result4);
$iiii=0;
while ($iiii < $num4) {

$plateno=mysql_result($result4,$iiii,"plateno");
$name=mysql_result($result4,$iiii,"name");
$phonenumber=mysql_result($result4,$iiii,"phonenumber");
$email=mysql_result($result4,$iiii,"email");
$paymentmode=mysql_result($result4,$iiii,"paymentmode");
$paymentoption=mysql_result($result4,$iiii,"paymentoption");
$fees=mysql_result($result4,$iiii,"fees");
$registrationdate =mysql_result($result4,$iiii,"date");



?>         
               <td><?php echo $plateno; ?></td>
               <td><?php echo $name; ?></td>
               <td><?php echo $phonenumber; ?></td>
               <td><?php echo $email; ?></td>
               <td><?php echo $paymentmode; ?></td>
               <td><?php echo $paymentoption; ?></td>
               <td><?php echo $fees; ?></td>
               <td><?php echo $registrationdate; ?></td>
        
          </tr>
        <?php
$iiii++;
}
?>          
                </tbody>
                <tfoot>
                  <tr>
                      <th>Plate No</th>
                      <th>Name</th>
                      <th>Phone Number</th>
                      <th>Email</th>
                      <th>Payment Mode</th>
                      <th>Payment Option</th>
                      <th>Fees</th>
                      <th>Date</th>
                     
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
        </div>  
<?php
}

}
?>
               


                </div>
                
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="content-overlay"></div>
    </div>
  </div>
</div>

<!-- END: Page Main-->
<?php include 'comon/footer.php';?>