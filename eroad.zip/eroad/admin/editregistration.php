<?php
@session_start();
if(!isset($_SESSION['SESS_login']))
{
header("location: index.php");
}
include 'comon/header.php';
include 'comon/left.php';
include 'dbconfig.php';
?>
<!-- BEGIN: Page Main-->
<div id="main">
  <div class="row">

 <?php

if(isset($_POST['submit'])) 
{
$sql2="update vehiclelicense set name='$_POST[name]'
,address='$_POST[address]',phonenumber='$_POST[phonenumber]',email='$_POST[email]',chassissno='$_POST[chassissno]',registrationno='$_POST[registrationno]'
 WHERE id=".$_GET['id']." ";  
  
$result2 = mysql_query($sql2);

$sql3="update preregistration set IsUsed='1' WHERE PreRegistrationNo='$_POST[registrationno]'";  
$result3 = mysql_query($sql3);

?>

<script> location.replace("thankyou.php?status=registrationapprove&registrationno=<?php echo $_POST['registrationno'];?>&amount=<?php echo $_POST['registrationfee'];?>&pmode=<?php echo $_POST['paymentoption'];?>"); </script>

<!-- <div class="card-alert card gradient-45deg-green-teal">
    <div class="card-content white-text">
      <p>
         <i class="material-icons">check</i> Registration Updated Successfully........... !
      </p>
    </div>
</div> -->
<?php
}
?> 

<?php
$GetPhotoSQL ="SELECT * FROM vehiclelicense WHERE id = ".$_GET['id']." LIMIT 1";
$GetPhotoResult = mysql_query($GetPhotoSQL);
$GetPhotoRow = mysql_fetch_array($GetPhotoResult);
?>  

    <div class="content-wrapper-before gradient-45deg-indigo-purple"></div>
    <div class="breadcrumbs-dark pb-0 pt-4" id="breadcrumbs-wrapper">
      <!-- Search for small screen-->
      <div class="container">
        
      </div>
    </div>
    <div class="col s12">
      <div class="container">
        
        <!-- Input Fields -->
        <div class="row">
          <div class="col s12">
            <div id="input-fields" class="card card-tabs">
              <div class="card-content">
                <div class="card-title">
                  <div class="row">
                    <div class="col s12 m6 l10">
                      <h4 class="card-title">REGISTRATION</h4>
                    </div>
                    
                  </div>
                </div>
                <div id="view-input-fields">
                  <div class="row">
                    <div class="col s12">
                      
                      <form  method="post">

                         <div class="col m12 s12" style="visibility: hidden;">
                          <div class="input-field col s12">
                            <input id="rno" type="text" name="rno"
                            value="<?php echo $GetPhotoRow['registrationno'];?>">
                          </div>
                        </div>

                        <div class="col s12">
                          <div class="input-field col m6 s12">
                            <input placeholder="Placeholder" id="date" type="date" name="registrationdate" onchange="getdate()" required="" readonly="" value="<?php echo $GetPhotoRow['registrationdate'];?>">
                            <label for="first_name1">Registration Date </label>
                          </div>

                          
                          <div class="input-field col m6 s12">
                            <select id="registrationno" name="registrationno" >
                              <option value="" disabled selected>Choose your option</option>

                              <?php 
                              if($GetPhotoRow['registrationno']!='')
                              {
                                $query4="SELECT * FROM preregistration";
                              }
                              else
                              {
                                $query4="SELECT * FROM preregistration where IsUsed=0 ORDER BY id ASC";
                              }
                  $result4=mysql_query($query4);
                  $num4=mysql_numrows($result4);
                  $iiii=0;
                  while ($iiii < $num4) {
                  
                  $projects_id4=mysql_result($result4,$iiii,"PreRegistrationNo");
                  $projects_name4=mysql_result($result4,$iiii,"PreRegistrationNo");
  
                  if ($GetPhotoRow['registrationno']==$projects_id4)
                  {
                  ?>
                  <option selected value="<?php echo $projects_id4; ?>"><?php echo $projects_name4; ?></option>
                  <?php
                  }
                  else
                  {
                  ?>
                  <option value="<?php echo $projects_id4; ?>"><?php echo $projects_name4; ?></option>
                  <?php 
                  }
                  $iiii++;
                  }
                  ?>

                             
                            </select>
                            <label for="last_name">Select Plate Number</label>
                          </div>


                        </div>
                        
                        <div class="col m6 s12">
                          <div class="input-field col s12">
                            <input id="password" type="text" name="name" required=""
                            value="<?php echo $GetPhotoRow['name'];?>">
                            <label for="password">Name of Owner</label>
                          </div>
                        </div>
                        <div class="col m6 s12">
                          <div class="input-field col s12">
                            <input id="email3" type="text"  name="phonenumber" required=""
                            value="<?php echo $GetPhotoRow['phonenumber'];?>">
                            <label for="email3">Phone No of Owner </label>
                          </div>
                        </div>
                        <div class="col m6 s12">
                          <div class="input-field col s12">
                            <textarea id="icon_prefix2" name="address" required="" class="materialize-textarea"><?php echo $GetPhotoRow['address'];?></textarea>
                            <label for="icon_prefix2">Address of Owner</label>
                          </div>
                        </div>
                        <div class="col m6 s12">
                          <div class="input-field col s12">
                            <input id="password" type="email" name="email" required=""
                            value="<?php echo $GetPhotoRow['email'];?>">
                            <label for="password">Email</label>
                          </div>
                        </div>
                        <div class="col m6 s12">
                          <div class="input-field col s12">
                            <input id="email3" type="text" required="" name="chassissno"
                            value="<?php echo $GetPhotoRow['chassissno'];?>">
                            <label for="email3">Chassiss No </label>
                          </div>
                        </div>
                        <div class="input-field col m4 s12">
                          <select readonly="" id="useofvehicle" name="useofvehicle" onchange="getdate()" required="">
                            <option value="" disabled selected>Choose your option</option>
                        
                         <option value="Private" <?php if($GetPhotoRow['useofvehicle'] == "Private") echo "selected"; ?>>Private</option>
                              <option value="Commercial" <?php if($GetPhotoRow['useofvehicle'] == "Commercial") echo "selected"; ?>>Commercial</option>
                          </select>
                          <label for="last_name">Use of Vehicle</label>
                        </div>
                        <div class="input-field col m4 s12">
                          <select readonly="" id="typeofvehicle" name="typeofvehicle" required="">
                            <option value="" disabled selected>Choose your option</option>
                        
                                 <option value="Motorcycle/Tricycle" <?php if($GetPhotoRow['typeofvehicle'] == "Motorcycle/Tricycle") echo "selected"; ?>>Motorcycle/Tricycle</option>

                                   <option value="Car" <?php if($GetPhotoRow['typeofvehicle'] == "Car") echo "selected"; ?>>Car</option>

                                   <option value="Bus/SUV/Jeep" <?php if($GetPhotoRow['typeofvehicle'] == "Bus/SUV/Jeep") echo "selected"; ?>>Bus/SUV/Jeep</option>

                                   <option value="Tipper/Trailer" <?php if($GetPhotoRow['typeofvehicle'] == "Tipper/Trailer") echo "selected"; ?>>Tipper/Trailer</option>



                          </select>
                          <label for="last_name">Type of Vehicle</label>
                        </div>
                        <div class="col m4 s12">
                          <div class="input-field col s12">
                            <input  type="text" name="duedate" id="duedate" readonly=""
                            value="<?php echo $GetPhotoRow['duedate'];?>">
                            <label for="email3">Expiry Date </label>
                          </div>
                        </div>
                        <?php 
                          $pay_type=$GetPhotoRow['typesofpayment'];
                          $pay_types=explode(",", $pay_type);
                         
                        ?>
                        <div id="view-checkboxes">
                          <label for="payment" style="color:#6d6969;font-weight: bold;">Type of Payment</label>
                          <div class="input-field col m6 s12">

                            <?php if(in_array('Vehicle Licence',$pay_types)) { ?>
                              <p class="mb-1">
                              <label>
                                <input disabled="" class="payment" type="checkbox" value="Vehicle Licence" id="payment1" name="typesofpayment[]" checked="checked" />
                                 <span>Vehicle Licence</span>
                                    </label>
                            </p>
                            <?php } else{ ?> 
                                <p class="mb-1">
                              <label>
                                <input disabled="" class="payment" type="checkbox" value="Vehicle Licence" id="payment1" name="typesofpayment[]"/>
                                 <span>Vehicle Licence</span>
                                    </label>
                            </p>
                            <?php } ?>



                            <?php if(in_array('Road Worthiness',$pay_types)) { ?>
                              <p class="mb-1">
                              <label>
                                 <input disabled="" class="payment" type="checkbox" value="Road Worthiness" id="payment2" name="typesofpayment[]" checked="checked"/>
                                <span>Road Worthiness</span>
                                    </label>
                            </p>
                            <?php } else{ ?> 
                               <p class="mb-1">
                              <label>
                                 <input disabled="" class="payment" type="checkbox" value="Road Worthiness" id="payment2" name="typesofpayment[]"/>
                                <span>Road Worthiness</span>
                                    </label>
                            </p>
                            <?php } ?>


                            <?php if(in_array('Hackney Permit',$pay_types)) { ?>
                               <p class="mb-1">
                              <label>
                                   <input disabled="" class="payment" type="checkbox" value="Hackney Permit"  id="payment3" name="typesofpayment[]" checked="checked"/>
                                <span>Hackney Permit</span>
                                    </label>
                            </p>
                            <?php } else{ ?> 
                                <p class="mb-1">
                              <label>
                                   <input disabled="" class="payment" type="checkbox" value="Hackney Permit"  id="payment3" name="typesofpayment[]" />
                                <span>Hackney Permit</span>
                                    </label>
                            </p>
                            <?php } ?>


                             <?php if(in_array('Insurance',$pay_types)) { ?>
                               <p class="mb-1">
                              <label>
                                   <input disabled="" class="payment" type="checkbox" value="Insurance" id="payment4" name="typesofpayment[]" checked="checked" />
                                <span>Insurance </span>
                                    </label>
                            </p>
                            <?php } else{ ?> 
                                 <p class="mb-1">
                              <label>
                                   <input disabled="" class="payment" type="checkbox" value="Insurance" id="payment4" name="typesofpayment[]" />
                                <span>Insurance </span>
                                    </label>
                            </p>
                            <?php } ?>


                            <?php if(in_array('Tipper/Trailer Permit',$pay_types)) { ?>
                               <p class="mb-1">
                              <label>
                                   <input disabled="" class="payment" type="checkbox" value="Tipper/Trailer Permit" id="payment4" name="typesofpayment[]" checked="checked" />
                                <span>Tipper/Trailer Permit </span>
                                    </label>
                            </p>
                            <?php } else{ ?> 
                                 <p class="mb-1">
                              <label>
                                   <input disabled="" class="payment" type="checkbox" value="Tipper/Trailer Permit" id="payment4" name="typesofpayment[]" />
                                <span>Tipper/Trailer Permit </span>
                                    </label>
                            </p>
                            <?php } ?>


                             <?php if(in_array('Number Plate',$pay_types)) { ?>
                               <p class="mb-1">
                              <label>
                                   <input disabled="" class="payment" type="checkbox" value="Number Plate" id="payment4" name="typesofpayment[]" checked="checked" />
                                <span>Number Plate </span>
                                    </label>
                            </p>
                            <?php } else{ ?> 
                                 <p class="mb-1">
                              <label>
                                   <input disabled="" class="payment" type="checkbox" value="Number Plate" id="payment4" name="typesofpayment[]" />
                                <span>Number Plate </span>
                                    </label>
                            </p>
                            <?php } ?>

                         
                            </div>
                        </div>
                     
                          <div class="col m4 s12">
                          <div class="input-field col s12">
                            <input id="amount" type="text" name="paymentoption" required="" readonly=""
                            value="<?php echo $GetPhotoRow['paymentoption'];?>">
                            <label for="email3">Payment Option </label>
                          </div>
                        </div>

                        <div class="col m4 s12">
                          <div class="input-field col s12">
                            <input onblur="check_pin()" type="text" class="form-control" name="pinnumber" id="pin" placeholder="PIN Number " readonly
                            value="<?php echo $GetPhotoRow['pinnumber'];?>" >
                             <div style="color:red;font-size:20px;" id="uname_response" class="response"
                             ></div> 
                            <label for="email3">PIN Number  </label>
                          </div>
                        </div>
                        <div class="col m4 s12">
                          <div class="input-field col s12">
                            <input id="amount" type="text" name="registrationfee" required="" readonly=""
                            value="<?php echo $GetPhotoRow['amount'];?>">
                            <label for="email3">Amount </label>
                          </div>
                        </div>
                    
                    <div class="col m12 s12">
                  <button class="btn mb-1 waves-effect waves-light" type="submit" name="submit">Submit  
                    <i class="material-icons right">send</i></button>
                  </div>
                       
                      </form>
                    </div>
                  </div>
                </div>
                
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="content-overlay"></div>
    </div>
  </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script> 

<script type="text/javascript">
  $( document ).ready(function() {
    var tt1 = document.getElementById('rno').value;
    if(tt1!='')
    {
      $('#registrationno').prop('disabled', true);
    }
});
</script>

<script>
    $(document).ready(function() {

      $('#useofvehicle').on('change',function(){
    var useofvehicle = $(this).val();  
    var typeofvehicle=$("#typeofvehicle").val();// value in field email
    var payment_type = [];
            $.each($("input[class='payment']:checked"), function(){
                payment_type.push("'"+$(this).val()+"'");
            });
            if(payment_type.length!=0){ payment_type=payment_type}else { payment_type="'Prime'";}
    $.ajax({
     type :'GET',
        dataType:'json',
    data:{useofvehicle: useofvehicle,typeofvehicle: typeofvehicle,paymenttype:payment_type},
        url : 'codegenrate.php?useofvehicle='+useofvehicle+'&typeofvehicle='+typeofvehicle+'&paymenttype='+payment_type,
        success : function(result){
    $('#amount').val(result['fees']);
    }
   });
  }); 

  $(".payment").click(function(){
    //alert();
        var useofvehicle =$("#useofvehicle").val();// value in field email
        var typeofvehicle=$("#typeofvehicle").val();// value in field email
        var payment_type = [];
        $.each($("input[class='payment']:checked"), function(){
            payment_type.push("'"+$(this).val()+"'");
        });
        if(payment_type.length!=0){ payment_type=payment_type}else { payment_type="'Prime'";}
          $.ajax({
         type :'GET',
            dataType:'json',
           url : 'codegenrate.php?useofvehicle='+useofvehicle+'&typeofvehicle='+typeofvehicle+'&paymenttype='+payment_type,
            success : function(result){
            $('#amount').val(result['fees']);
            M.updateTextFields();
        }
        });
  });


  $('#typeofvehicle').on('change',function(){
  var typeofvehicle = $(this).val();  
  var useofvehicle=$("#useofvehicle").val();// value in field email
  var payment_type = [];
        $.each($("input[class='payment']:checked"), function(){
            payment_type.push("'"+$(this).val()+"'");
        });
        if(payment_type.length!=0){ payment_type=payment_type}else { payment_type="'Prime'";}
  $.ajax({
   type :'GET',
      dataType:'json',
 // data:{country_id: countryID,typeofvehicle: typeofvehicle,category:category},
     url : 'codegenrate.php?useofvehicle='+useofvehicle+'&typeofvehicle='+typeofvehicle+'&paymenttype='+payment_type,
      success : function(result){
  $('#amount').val(result['fees']);
  }

  });
  }); 


    });
</script>



<script>
$(document).ready(function(){
    $('#paymenttype').on('change',function(){
        var paymenttype = $(this).val();  
    if(paymenttype=="Online")
  {
    
    document.getElementById("pin").readOnly = true; 
  }
  else
  {
  document.getElementById("pin").readOnly = false; 
  }
    }); 
 }); 
function getdate() {
var tt1 = document.getElementById('useofvehicle').value;
if(tt1=='Private')
{
    var tt = document.getElementById('date').value;
    //alert(tt);
    var date = new Date(tt);
    var newdate = new Date(date);
    newdate.setDate(newdate.getDate() + 366);
    var dd = newdate.getDate();
    var mm = newdate.getMonth() + 1;
    var y = newdate.getFullYear();
    var someFormattedDate = dd + '/' + mm + '/' + y;
    document.getElementById('duedate').value = someFormattedDate;
    M.updateTextFields();
  //$('select').formSelect();
} 
else if(tt1=='Commercial')
{
    var tt = document.getElementById('date').value;
    var date = new Date(tt);
    var newdate = new Date(date);
    newdate.setDate(newdate.getDate() + 183);
    var dd = newdate.getDate();
    var mm = newdate.getMonth() + 1;
    var y = newdate.getFullYear();
    var someFormattedDate = dd + '/' + mm + '/' + y;
    document.getElementById('duedate').value = someFormattedDate;
}
}
</script>   
<script type="text/javascript">
function check_pin(){
var pin=$("#pin").val();// value in field email
var category='Vehicle License';
$.ajax({
    type:'post',
      url:'checkpinexists.php',// put your real file name 
        //data:{pin: pin},
    data:{pin: pin,category: category},
        success:function(msg){
    if(msg>0)
    {
     $("#uname_response").hide();
    }
    else
    {
     $("#uname_response").show();
     $("#uname_response").html("<span class='not-exists'>* PIN Not Available.</span>");
         //alert(msg); // your message will come here.  
     $('#pin').val(''); //txtID is textbox ID
    // $("#pin").focus();
    }   
        }
 });
}
</script>     
<script>
function validateForm() {
var paymentoption=document.forms["myForm"]["paymentoption"].value;
if(paymentoption=='PIN')
{
  var x = document.forms["myForm"]["pinnumber"].value;
  if (x == "") {
    alert("Please Enter PIN");
  $('#pin').val(''); //txtID is textbox ID
  //$("#pin").focus();
    return false;
  }
  }
} 
</script>  
<!-- END: Page Main-->
<?php include 'comon/footer.php';?>