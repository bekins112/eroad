<?php

include "dbconfig.php";

/* Get username */
$chassissno = $_GET['chassissno'];

/* Query */
$query = "select count(*) as cntUser from vehiclelicense where chassissno='".$chassissno."'";

$result = mysql_query($query);
$row = mysql_fetch_array($result);
$count = $row['cntUser'];

echo $count;
?>