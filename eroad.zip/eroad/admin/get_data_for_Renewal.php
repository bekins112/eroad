

<?php include("dbconfig.php");
$country_id= $_POST['country_id'];

$mysqli = new mysqli($dbserver,$username,$password,$database);
//echo($zip1);
//die;

 $qry="SELECT * FROM vehiclelicense where registrationno='$country_id'";
 	  $result=mysqli_query($mysqli,$qry);
      $rowcount=mysqli_fetch_assoc($result);
echo json_encode($rowcount);

