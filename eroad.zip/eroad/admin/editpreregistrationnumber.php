<?php
@session_start();
if(!isset($_SESSION['SESS_login']))
{
header("location: index.php");
}
include 'comon/header.php';
include 'comon/left.php';
include 'dbconfig.php';
?>
<!-- BEGIN: Page Main-->
<div id="main">
  <div class="row">
    <div class="content-wrapper-before gradient-45deg-indigo-purple"></div>
    <div class="breadcrumbs-dark pb-0 pt-4" id="breadcrumbs-wrapper">
      <!-- Search for small screen-->
      <div class="container">
 <?php

if(isset($_POST['submit'])) 
{


$sql2="update preregistration set PreRegistrationNo='$_POST[PreRegistrationNo]'
 WHERE id=".$_GET['id']." ";           
$result2 = mysql_query($sql2);
?>
<div class="card-alert card gradient-45deg-green-teal">
    <div class="card-content white-text">
      <p>
         <i class="material-icons">check</i> Plate Number Updated Successfully........... !
      </p>
    </div>
</div>


<?php
}
?> 
<?php
$GetPhotoSQL ="SELECT * FROM preregistration WHERE id = ".$_GET['id']." LIMIT 1";
$GetPhotoResult = mysql_query($GetPhotoSQL);
$GetPhotoRow = mysql_fetch_array($GetPhotoResult);

?>
</div>
    </div>
    <div class="col s12">
      <div class="container">
        <!-- Input Fields -->
        <div class="row">
          <div class="col s12">
            <div id="input-fields" class="card card-tabs">
              <div class="card-content">
                <div class="card-title">
                  <div class="row">
                    <div class="col s12 m6 l10">
                      <h4 class="card-title">Edit Plate Number</h4>
                    </div>
                  </div>
                </div>
                <div id="view-input-fields">
                  <div class="row">
                    <div class="col s12">
                      <form  method="post" action="">
                        <div class="col s12">
                          <div class="input-field col s12">
                            <input  name="PreRegistrationNo" id="PreRegistrationNo" type="text"  required=""
                            value="<?php echo $GetPhotoRow['PreRegistrationNo'];?>">
                            <label for="password">Plate Number</label>
                          </div>
                        </div>
                        
                       
                  <button class="btn mb-1 waves-effect waves-light" type="submit" name="submit">Submit  
                    <i class="material-icons right">send</i></button>
                      </form>
                    </div>
                  </div>
                </div>
                
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="content-overlay"></div>
    </div>
  </div>
</div>
<!-- END: Page Main-->
<?php include 'comon/footer.php';?>