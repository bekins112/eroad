<?php
@session_start();
if(!isset($_SESSION['SESS_login']))
{
header("location: index.php");
}
include 'comon/header.php';
include 'comon/left.php';
include 'dbconfig.php';
?>
<!-- BEGIN: Page Main-->
<div id="main">
  <div class="row">
    <div class="content-wrapper-before gradient-45deg-indigo-purple"></div>
    <div class="breadcrumbs-dark pb-0 pt-4" id="breadcrumbs-wrapper">
      <!-- Search for small screen-->
      <div class="container">
 <?php

if(isset($_POST['submit'])) 
{


$sql2="INSERT INTO feesmaster (useofvehicle,typeofvehicle,fees,category) 
VALUES ('$_POST[useofvehicle]','$_POST[typeofvehicle]','$_POST[fees]','$_POST[category]')";
           
$result2 = mysql_query($sql2);
?>
<div class="card-alert card gradient-45deg-green-teal">
    <div class="card-content white-text">
      <p>
         <i class="material-icons">check</i>Fees Added Successfully........... !
      </p>
    </div>
</div>

<?php
}
?>   
</div>
    </div>
    <div class="col s12">
      <div class="container">
        <!-- Input Fields -->
        <div class="row">
          <div class="col s12">
            <div id="input-fields" class="card card-tabs">
              <div class="card-content">
                <div class="card-title">
                  <div class="row">
                    <div class="col s12 m6 l10">
                      <h4 class="card-title">Generate Fees</h4>
                    </div>
                  </div>
                </div>
                <div id="view-input-fields">
                  <div class="row">
                    <div class="col s12">
                      <form  method="post" action="">
                        <div class="col m6 s12">
                          <div class="input-field col s12">
                           <select class="form-control" name="category" required>
                              <option value="">Choose your option</option>
                              <option value="Vehicle Licence">Vehicle Licence</option>
                              <option value="Road Worthiness">Road Worthiness</option>
                              <option value="Insurance">Insurance</option>
                              <option value="Hackney Permit">Hackney Permit</option>
                              <option value="Tipper/Trailer Permit">Tipper/Trailer Permit</option>
                              <option value="Number Plate">Number Plate</option>
                           </select>
                            <label for="password">Select Category</label>
                          </div>
                        </div>
                        <div class="col m6 s12">
                          <div class="input-field col s12">
                             <select class="form-control" name="useofvehicle" required>
                                <option value="">Choose your option</option>
                                <option value="Private">Private</option>
                                <option value="Commercial">Commercial</option>
                            </select>
                            <label for="password">Use of Vehicle</label>
                          </div>
                        </div>
                        <div class="col m6 s12">
                          <div class="input-field col s12">
                            <select class="form-control" name="typeofvehicle" required>
                                <option value="">Choose your option</option>
                                <option value="Motorcycle/Tricycle">Motorcycle/Tricycle</option>
                                <option value="Car">Car</option>
                                <option value="Bus/SUV/Jeep">Bus/SUV/Jeep</option>
                                <option value="Tipper/Trailer">Tipper/Trailer</option>
                            </select>
                            <label for="password">Type of Vehicle</label>
                          </div>
                        </div>
                       <div class="col m6 s12">
                          <div class="input-field col s12">
                            <input name="fees" id="password" type="text" required="">
                            <label for="password">Service Charge</label>
                          </div>
                        </div>
                  <button class="btn mb-1 waves-effect waves-light" type="submit" name="submit">Submit  
                    <i class="material-icons right">send</i></button>
                      </form>
                    </div>
                  </div>
                </div>
                
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="content-overlay"></div>
    </div>
  </div>
</div>
<!-- END: Page Main-->
<?php include 'comon/footer.php';?>