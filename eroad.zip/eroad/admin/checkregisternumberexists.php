<?php

include "dbconfig.php";

/* Get username */
$PreRegistrationNo = $_POST['PreRegistrationNo'];


/* Query */
$query = "select count(*) as cntUser from preregistration where PreRegistrationNo='".$PreRegistrationNo."'";

$result = mysql_query($query);

$row = mysql_fetch_array($result);

$count = $row['cntUser'];

echo $count;