
<!-- BEGIN: Footer-->
<footer class="page-footer footer footer-static footer-dark gradient-45deg-indigo-purple gradient-shadow navbar-border navbar-shadow">
<div class="footer-copyright">
<div class="container"><span>&copy; 2020 | Rizquad Technnology Limited          <a href="eroad" target="_blank">E-ROAD</a> All rights reserved.</span><span class="right hide-on-small-only">Design and Developed by <a href="https://renownedtechng.com">RenownedTechng</a></span></div>
        </div>
        </footer>
        <!-- END: Footer-->
        <!-- BEGIN VENDOR JS-->
        <script src="app-assets/js/vendors.min.js"></script>
        <!-- BEGIN VENDOR JS-->
        <!-- BEGIN PAGE VENDOR JS-->
        <script src="app-assets/vendors/chartjs/chart.min.js"></script>
        <script src="app-assets/vendors/chartist-js/chartist.min.js"></script>
        <script src="app-assets/vendors/chartist-js/chartist-plugin-tooltip.js"></script>
        <script src="app-assets/vendors/chartist-js/chartist-plugin-fill-donut.min.js"></script>
        <!-- END PAGE VENDOR JS-->
        <!-- BEGIN THEME  JS-->
        <script src="app-assets/js/plugins.min.js"></script>
        <script src="app-assets/js/search.min.js"></script>
        <script src="app-assets/js/custom/custom-script.min.js"></script>
        <script src="app-assets/js/scripts/customizer.min.js"></script>
         <script src="app-assets/vendors/data-tables/js/jquery.dataTables.min.js"></script>
    <script src="app-assets/vendors/data-tables/extensions/responsive/js/dataTables.responsive.min.js"></script>
    <script src="app-assets/vendors/data-tables/js/dataTables.select.min.js"></script>
      <script src="app-assets/js/scripts/data-tables.min.js"></script>
        <!-- END THEME  JS-->
        <!-- BEGIN PAGE LEVEL JS-->
        <script src="app-assets/js/scripts/dashboard-modern.js"></script>
        <script src="app-assets/js/scripts/intro.min.js"></script>





  <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script>
  <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/1.6.1/js/dataTables.buttons.min.js"></script>
  <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.bootstrap4.min.js"></script>
  <script type="text/javascript" language="javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
  <script type="text/javascript" language="javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
  <script type="text/javascript" language="javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
  <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.html5.min.js"></script>
  <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.print.min.js"></script>
  <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.colVis.min.js"></script>

 <script src="js/datatables.min.js" type="text/javascript"></script>
    <script src="js/datatable-basic.js" type="text/javascript"></script>

  <script type="text/javascript">
    $(document).ready(function() {
    var table = $('#example').DataTable( {
        lengthChange: false,
        buttons: [ 'copy', 'excel', 'pdf' ]
    } );

    table.buttons().container()
        .appendTo( '#example_wrapper .col-md-6:eq(0)' );
} );
  </script>
        <!-- END PAGE LEVEL JS-->

        <script type="text/javascript">
         $( "#date" ).datepicker({ maxDate: '0' });

  });​
        </script>
</body>

</html>
