
   <?php
@session_start();
if(!isset($_SESSION['SESS_login']))
{
header("location:index.php");
}
$usertype=$_SESSION['SESS_USER_TYPE'];
?>

    <!-- BEGIN: SideNav-->
    <aside class="sidenav-main nav-expanded nav-lock nav-collapsible sidenav-light sidenav-active-square">
        <div class="brand-sidebar">
            <h1 class="logo-wrapper"><a class="brand-logo darken-1" href="dashboard.php">
            	<img class="hide-on-med-and-down" src="logo.jpg" alt="materialize logo"/></a>
            </h1>
        </div>
        <ul class="sidenav sidenav-collapsible leftside-navigation collapsible sidenav-fixed menu-shadow" id="slide-out" data-menu="menu-navigation" data-collapsible="menu-accordion">
        	<li class="bold"><a class="waves-effect waves-cyan " href="dashboard.php"><i class="material-icons">settings_input_svideo</i><span class="menu-title" data-i18n="Chat">Dashboard</span></a>
            </li>
        <?php if($usertype=="Super Admin") 
        {
        ?>  
             <li><a class="collapsible-header waves-effect waves-cyan " href="JavaScript:void(0)"><i class="material-icons">settings_input_svideo</i><span class="menu-title" data-i18n="Dashboard">Plate Number Master </span></a>
                <div class="collapsible-body">
                    <ul class="collapsible collapsible-sub" data-collapsible="accordion">
                        <li><a href="preregistrationnumber.php"><i class="material-icons">radio_button_unchecked</i><span data-i18n="Modern">Add New</span></a>
                        </li>
                        <li><a href="managepreregistrationnumber.php"><i class="material-icons">radio_button_unchecked</i><span data-i18n="eCommerce">Manage Number</span></a>
                        </li>
                        
                    </ul>
                </div>
            </li>

             <li><a class="collapsible-header waves-effect waves-cyan " href="JavaScript:void(0)"><i class="material-icons">settings_input_svideo</i><span class="menu-title" data-i18n="Dashboard">Fees Master</span></a>
                <div class="collapsible-body">
                    <ul class="collapsible collapsible-sub" data-collapsible="accordion">
                        <li><a href="addfees.php"><i class="material-icons">radio_button_unchecked</i><span data-i18n="Modern">Add Fees</span></a>
                        </li>
                        <li><a href="managefees.php"><i class="material-icons">radio_button_unchecked</i><span data-i18n="eCommerce">Manage Fees</span></a>
                        </li>
                    </ul>
                </div>
            </li>
            
             <li><a class="collapsible-header waves-effect waves-cyan " href="JavaScript:void(0)"><i class="material-icons">settings_input_svideo</i><span class="menu-title" data-i18n="Dashboard">PIN Master</span></a>
                <div class="collapsible-body">
                    <ul class="collapsible collapsible-sub" data-collapsible="accordion">
                        <li><a href="addpin.php"><i class="material-icons">radio_button_unchecked</i><span data-i18n="Modern">Add PIN</span></a>
                        </li>
                        <li><a href="managepin.php"><i class="material-icons">radio_button_unchecked</i><span data-i18n="eCommerce">Manage PIN</span></a>
                        </li>
                    </ul>
                </div>
            </li>
            

           <li><a class="collapsible-header waves-effect waves-cyan " href="JavaScript:void(0)"><i class="material-icons">settings_input_svideo</i><span class="menu-title" data-i18n="Dashboard">Admin Master</span></a>
                <div class="collapsible-body">
                    <ul class="collapsible collapsible-sub" data-collapsible="accordion">
                        <li><a href="addadmin.php"><i class="material-icons">radio_button_unchecked</i><span data-i18n="Modern">Add Admin</span></a>
                        </li>
                        <li><a href="manageadmin.php"><i class="material-icons">radio_button_unchecked</i><span data-i18n="eCommerce">Manage Admin</span></a>
                        </li>
                        
                    </ul>
                </div>
            </li>
             

             
            <li><a class="collapsible-header waves-effect waves-cyan " href="JavaScript:void(0)"><i class="material-icons">settings_input_svideo</i><span class="menu-title" data-i18n="Dashboard">Vechicle Registration</span></a>
                <div class="collapsible-body">
                    <ul class="collapsible collapsible-sub" data-collapsible="accordion">
                        <li><a href="registration.php"><i class="material-icons">radio_button_unchecked</i><span data-i18n="Modern">Registration</span></a>
                        </li>
                        <li><a href="manage-vehicle-registration.php"><i class="material-icons">radio_button_unchecked</i><span data-i18n="Modern">Manage</span></a>
                        </li>
                        
                        <li><a href="renewal.php"><i class="material-icons">radio_button_unchecked</i><span data-i18n="eCommerce">Renewal</span></a>
                        </li>
                    </ul>
                </div>
            </li>
          <!--    <li><a class="collapsible-header waves-effect waves-cyan " href="JavaScript:void(0)"><i class="material-icons">settings_input_svideo</i><span class="menu-title" data-i18n="Dashboard">Reports</span></a>
                <div class="collapsible-body">
                    <ul class="collapsible collapsible-sub" data-collapsible="accordion">
                        <li><a href="registration-report.php"><i class="material-icons">radio_button_unchecked</i><span data-i18n="Modern">Registred Report</span></a>
                        </li>
                        <li><a href="renewal-report.php"><i class="material-icons">radio_button_unchecked</i><span data-i18n="eCommerce">Renewal Report</span></a>
                        </li>
                    </ul>
                </div>
            </li> -->
             <li class="bold"><a class="waves-effect waves-cyan " href="report.php"><i class="material-icons">settings_input_svideo</i><span class="menu-title" data-i18n="Chat">Report</span></a>
            </li>
            <li class="bold"><a class="waves-effect waves-cyan " href="logout.php"><i class="material-icons">settings_input_svideo</i><span class="menu-title" data-i18n="Chat">Log  Out</span></a>
            </li>
    <?php
}

else if($usertype=="Admin Officers") 
        {
        ?>

            <li><a class="collapsible-header waves-effect waves-cyan " href="JavaScript:void(0)"><i class="material-icons">settings_input_svideo</i><span class="menu-title" data-i18n="Dashboard">Vechicle Registration</span></a>
                <div class="collapsible-body">
                    <ul class="collapsible collapsible-sub" data-collapsible="accordion">
                        <li><a href="registration.php"><i class="material-icons">radio_button_unchecked</i><span data-i18n="Modern">Registration</span></a>
                        </li>
                        <li><a href="manage-vehicle-registration.php"><i class="material-icons">radio_button_unchecked</i><span data-i18n="Modern">Manage</span></a>
                        </li>
                    </ul>

            </li>
   <li class="bold"><a class="waves-effect waves-cyan " href="report.php"><i class="material-icons">settings_input_svideo</i><span class="menu-title" data-i18n="Chat">Report</span></a>
            </li>
                        <li class="bold"><a class="waves-effect waves-cyan " href="logout.php"><i class="material-icons">settings_input_svideo</i><span class="menu-title" data-i18n="Chat">Log  Out</span></a></li>
                      
                     
          <?php
}  
else if($usertype=="Admin Manager") 
        {
        ?>  
             <li><a class="collapsible-header waves-effect waves-cyan " href="JavaScript:void(0)"><i class="material-icons">settings_input_svideo</i><span class="menu-title" data-i18n="Dashboard">Plate Number Master </span></a>
                <div class="collapsible-body">
                    <ul class="collapsible collapsible-sub" data-collapsible="accordion">
                        <li><a href="preregistrationnumber.php"><i class="material-icons">radio_button_unchecked</i><span data-i18n="Modern">Add New</span></a>
                        </li>
                        <li><a href="managepreregistrationnumber.php"><i class="material-icons">radio_button_unchecked</i><span data-i18n="eCommerce">Manage Number</span></a>
                        </li>
                        
                    </ul>
                </div>
            </li>

             <li><a class="collapsible-header waves-effect waves-cyan " href="JavaScript:void(0)"><i class="material-icons">settings_input_svideo</i><span class="menu-title" data-i18n="Dashboard">Fees Master</span></a>
                <div class="collapsible-body">
                    <ul class="collapsible collapsible-sub" data-collapsible="accordion">
                        <li><a href="addfees.php"><i class="material-icons">radio_button_unchecked</i><span data-i18n="Modern">Add Fees</span></a>
                        </li>
                        <li><a href="managefees.php"><i class="material-icons">radio_button_unchecked</i><span data-i18n="eCommerce">Manage Fees</span></a>
                        </li>
                    </ul>
                </div>
            </li>
            
             <li><a class="collapsible-header waves-effect waves-cyan " href="JavaScript:void(0)"><i class="material-icons">settings_input_svideo</i><span class="menu-title" data-i18n="Dashboard">PIN Master</span></a>
                <div class="collapsible-body">
                    <ul class="collapsible collapsible-sub" data-collapsible="accordion">
                        <li><a href="addpin.php"><i class="material-icons">radio_button_unchecked</i><span data-i18n="Modern">Add PIN</span></a>
                        </li>
                        <li><a href="managepin.php"><i class="material-icons">radio_button_unchecked</i><span data-i18n="eCommerce">Manage PIN</span></a>
                        </li>
                    </ul>
                </div>
            </li>
            

       

             
            <li><a class="collapsible-header waves-effect waves-cyan " href="JavaScript:void(0)"><i class="material-icons">settings_input_svideo</i><span class="menu-title" data-i18n="Dashboard">Vechicle Registration</span></a>
                <div class="collapsible-body">
                    <ul class="collapsible collapsible-sub" data-collapsible="accordion">
                        <li><a href="registration.php"><i class="material-icons">radio_button_unchecked</i><span data-i18n="Modern">Registration</span></a>
                        </li>
                        <li><a href="manage-vehicle-registration.php"><i class="material-icons">radio_button_unchecked</i><span data-i18n="Modern">Manage</span></a>
                        </li>
                        
                        <li><a href="renewal.php"><i class="material-icons">radio_button_unchecked</i><span data-i18n="eCommerce">Renewal</span></a>
                        </li>
                    </ul>
                </div>
            </li>
          <!--    <li><a class="collapsible-header waves-effect waves-cyan " href="JavaScript:void(0)"><i class="material-icons">settings_input_svideo</i><span class="menu-title" data-i18n="Dashboard">Reports</span></a>
                <div class="collapsible-body">
                    <ul class="collapsible collapsible-sub" data-collapsible="accordion">
                        <li><a href="registration-report.php"><i class="material-icons">radio_button_unchecked</i><span data-i18n="Modern">Registred Report</span></a>
                        </li>
                        <li><a href="renewal-report.php"><i class="material-icons">radio_button_unchecked</i><span data-i18n="eCommerce">Renewal Report</span></a>
                        </li>
                    </ul>
                </div>
            </li> -->
             <li class="bold"><a class="waves-effect waves-cyan " href="report.php"><i class="material-icons">settings_input_svideo</i><span class="menu-title" data-i18n="Chat">Report</span></a>
            </li>
            <li class="bold"><a class="waves-effect waves-cyan " href="logout.php"><i class="material-icons">settings_input_svideo</i><span class="menu-title" data-i18n="Chat">Log  Out</span></a>
            </li>
    <?php
} 
else if($usertype=="Account Admin") 
        {
        ?>              

           <li><a class="collapsible-header waves-effect waves-cyan " href="JavaScript:void(0)"><i class="material-icons">settings_input_svideo</i><span class="menu-title" data-i18n="Dashboard">Plate Number Master </span></a>
                <div class="collapsible-body">
                    <ul class="collapsible collapsible-sub" data-collapsible="accordion">
                        <li><a href="preregistrationnumber.php"><i class="material-icons">radio_button_unchecked</i><span data-i18n="Modern">Add New</span></a>
                        </li>
                        <li><a href="managepreregistrationnumber.php"><i class="material-icons">radio_button_unchecked</i><span data-i18n="eCommerce">Manage Number</span></a>
                        </li>
                        
                    </ul>
                </div>
            </li>

        
              <li><a class="collapsible-header waves-effect waves-cyan " href="JavaScript:void(0)"><i class="material-icons">settings_input_svideo</i><span class="menu-title" data-i18n="Dashboard">Vechicle Registration</span></a>
                <div class="collapsible-body">
                    <ul class="collapsible collapsible-sub" data-collapsible="accordion">
                        <li><a href="registration.php"><i class="material-icons">radio_button_unchecked</i><span data-i18n="Modern">Registration</span></a>
                        </li>
                        <li><a href="manage-vehicle-registration.php"><i class="material-icons">radio_button_unchecked</i><span data-i18n="Modern">Manage</span></a>
                        </li>
                    </ul>

            </li>

                   <!--   <li><a class="collapsible-header waves-effect waves-cyan " href="JavaScript:void(0)"><i class="material-icons">settings_input_svideo</i><span class="menu-title" data-i18n="Dashboard">Reports</span></a>
                <div class="collapsible-body">
                    <ul class="collapsible collapsible-sub" data-collapsible="accordion">
                        <li><a href="registration-report.php"><i class="material-icons">radio_button_unchecked</i><span data-i18n="Modern">Registred Report</span></a>
                        </li>
                        <li><a href="renewal-report.php"><i class="material-icons">radio_button_unchecked</i><span data-i18n="eCommerce">Renewal Report</span></a>
                        </li>
                    </ul>
                </div>
            </li> -->
             <li class="bold"><a class="waves-effect waves-cyan " href="report.php"><i class="material-icons">settings_input_svideo</i><span class="menu-title" data-i18n="Chat">Report</span></a>
            </li>
            <li class="bold"><a class="waves-effect waves-cyan " href="logout.php"><i class="material-icons">settings_input_svideo</i><span class="menu-title" data-i18n="Chat">Log  Out</span></a>
            </li>

                        
                    </ul>
                </div>
            </li>
<?php
}       
?>  
        </ul>
        <div class="navigation-background"></div><a class="sidenav-trigger btn-sidenav-toggle btn-floating btn-medium waves-effect waves-light hide-on-large-only" href="#" data-target="slide-out"><i class="material-icons">menu</i></a>
    </aside>
    <!-- END: SideNav-->