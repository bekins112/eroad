<?php
include('../dbconfig.php');
$GetPhotoSQL ="SELECT vehiclelicense.paymentoption,vehiclelicense.amount,vehiclelicense.id,vehiclelicense.registrationno,vehiclelicense.name,vehiclelicense.phonenumber,vehiclelicense.useofvehicle,vehiclelicense.typeofvehicle,vehiclelicense.duedate,vehiclelicense.registrationdate FROM vehiclelicense WHERE vehiclelicense.registrationno = '".$_GET['registrationno']."' LIMIT 1";

/*$GetPhotoSQL ="SELECT vehiclelicense.paymentoption,vehiclelicense.amount,vehiclelicense.id,topscore.registrationdate,vehiclelicense.registrationno,topscore.Maxscore as duedate,vehiclelicense.name,vehiclelicense.phonenumber,vehiclelicense.useofvehicle,vehiclelicense.typeofvehicle FROM vehiclelicense INNER JOIN (SELECT registrationno, MAX(duedate) AS Maxscore, MAX(registrationdate) AS registrationdate FROM vehiclelicensedetails GROUP BY registrationno) topscore ON vehiclelicense.registrationno = topscore.registrationno WHERE vehiclelicense.registrationno = '".$_GET['registrationno']."' LIMIT 1";*/

$GetPhotoResult = mysql_query($GetPhotoSQL);
$GetPhotoRow = mysql_fetch_array($GetPhotoResult);
if (!isset($_GET['cmd']))
{
$_GET['cmd'] = "";
}
if($_GET["cmd"]=="Receipt")
{
if (!isset($_GET['registrationno']))
{
$_GET['registrationno'] = "";
}
$registrationno=$_GET['registrationno'];
$GetPhotoSQL1 ="SELECT receiptno FROM `vehiclelicense_receiptno` where registrationno='".$_GET['registrationno']."' order by receiptno DESC limit 1 ";
$GetPhotoResult1 = mysql_query($GetPhotoSQL1);
$GetPhotoRow1 = mysql_fetch_array($GetPhotoResult1);
}
else
{
$GetPhotoSQL1 ="SELECT receiptno FROM `vehiclelicense_receiptno` order by receiptno DESC limit 1 ";
$GetPhotoResult1 = mysql_query($GetPhotoSQL1);
$GetPhotoRow1 = mysql_fetch_array($GetPhotoResult1);
}
$html = '
<link rel="stylesheet" href="bootstrap.min.css">
   
      <div class="row">

        <div class="col-xs-3">
          <h1>
            <a href="http://easypay.primetechnosoft.in">            
            <img  src="../images/receipt.png">
            </a>
          </h1>
       </div>
	   <div class="col-xs-5 text-center">
         
            <p>304, Amora Arcade, Near Mouni International School,Utran, Surat-395006. </p>
			<p>Contact No : +91 9909334868</p>
          
       </div>
        <div class="col-xs-4 text-center">
          <h3>RECEIPT</h3>
          <h5>Receipt # '.$GetPhotoRow1['receiptno'].'</h5>
        </div>
		
		
		<table style="clear:both;">
	
		<div class="panel panel-default text-center">
            <div class="panel-heading">
              <h4><a href="#">VEHICLE LICENCE PAYMENT</a></h4>
            </div>
				<div class="col-xs-6 text-left"> 
           <div class="panel-body text-left">
		   
              <p>Registration No : '.$GetPhotoRow['registrationno'].'</p>
              <p>Issue To : '.$GetPhotoRow['name'].'</p>
              <p>Vehicle Type : '.$GetPhotoRow['typeofvehicle'].'</p>
              <p>Vehicle Use : '.$GetPhotoRow['useofvehicle'].'</p>
              <p>Issue Date : '.$GetPhotoRow['registrationdate'].' </p>
			  <p>Due Date : '.$GetPhotoRow['duedate'].'</p>
			  <p>Amount Paid : N'.$GetPhotoRow['amount'].'</p>
			  <p>Mode of Payment : '.$GetPhotoRow['paymentoption'].'</p>
			 
            </div>
          </div>
		  	
		  <div style="border:2px double #000;margin-top:20px;height:220px;" class="col-xs-5 text-left">
		   <div class="panel-heading">
              <h4><a href="#">INFORMATION</a></h4>
            </div>
           <div class="panel-body">
		   
              <p>SOME TEXT HERE...</p>
			 
           
          </div>
		  </div>
<div class="col-xs-1">
</div>		  
		   </div> 
	
		</table>
	  
 </div>';
//print_r($html);
//exit();
$filename = "Receipt";

// include autoloader
require_once 'dompdf/autoload.inc.php';

// reference the Dompdf namespace
use Dompdf\Dompdf;

// instantiate and use the dompdf class
$dompdf = new Dompdf();

$dompdf->loadHtml($html);

// (Optional) Setup the paper size and orientation
$dompdf->setPaper('A5', 'landscape');

// Render the HTML as PDF
$dompdf->render();

// Output the generated PDF to Browser
//$dompdf->stream($filename);
$dompdf->stream($filename, array("Attachment"=> 0));	

