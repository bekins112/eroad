<?php
require('textlocal.class.php');

$textlocal = new Textlocal('bekinsmart@gmail.com', '5D7kAMyB86CJGg*');

$numbers = array(448069463488);
$sender = 'EasyTax';
$message = 'This is a message';

try {
    $result = $textlocal->sendSms($numbers, $message, $sender);
    print_r($result);
} catch (Exception $e) {
    die('Error: ' . $e->getMessage());
}
?>