<?php
@session_start();
if(!isset($_SESSION['SESS_login']))
{
header("location: index.php");
}
include 'comon/header.php';
include 'comon/left.php';
include 'dbconfig.php';
?>
    <div id="main">
<div class="row">
<?php
				//////////// get_page_action and id start /////////
                if (!isset($_GET['cmd']))
                {
                $_GET['cmd'] = "";
                }
               	if($_GET["cmd"]=="delete")
				{
				if (!isset($_GET['id']))
				{
				$_GET['id'] = "";
				}
				$id=$_GET['id'];
				
				
				$sql = "DELETE From usermaster WHERE SrNo=$id";
				$result = mysql_query($sql);
		?>
<div class="card-alert card gradient-45deg-green-teal">
    <div class="card-content white-text">
      <p>
         <i class="material-icons">check</i> 
Admin Deleted Successfully........... !

      </p>
    </div>
</div>

          <?php
                }
				//////////// get_page_action and id start /////////
?>		

    <div class="col s12">
      <div class="card">
        <div class="card-content">
          <h4 class="card-title">Manage Admin
          </h4>
          <div class="row">
            <div class="col s12">
              <table id="example" class="display">
                <thead>
                  <tr>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Contact No</th>
                    <th>Email</th>
                    <th>Username</th>
                    <th>Admin Type</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                	<tr>
                		<?php
$query4="SELECT * FROM usermaster order by SrNo DESC";
$result4=mysql_query($query4);
$num4=mysql_numrows($result4);
$iiii=0;
while ($iiii < $num4) {
$Id=mysql_result($result4,$iiii,"SrNo");
$firstname=mysql_result($result4,$iiii,"firstname");
$lastname=mysql_result($result4,$iiii,"lastname");
$contactno=mysql_result($result4,$iiii,"contactno");
$email=mysql_result($result4,$iiii,"email");
$usertype=mysql_result($result4,$iiii,"usertype");
$UserName=mysql_result($result4,$iiii,"UserName");

?>						
                             <td><?php echo $firstname; ?></td>
							  <td><?php echo $lastname; ?></td>
							 <td><?php echo $contactno; ?></td>
							 <td><?php echo $email; ?></td>
							 <td><?php echo $UserName; ?></td>
							 <td><?php echo $usertype; ?></td>
                           <td>
								<a href="editadmin.php?id=<?php  echo $Id; ?>&cmd=edit"> <i class="material-icons dp48">border_color</i> </a> &nbsp;&nbsp;
								  <a href="manageadmin.php?id=<?php  echo $Id; ?>&cmd=delete" ><i class="material-icons dp48">delete</i> </a>
							</td>
                           
                        </tr>
        <?php
$iiii++;
}
?>          

                  
                 
                </tbody>
                <tfoot>
                  <tr>
                     <th>First Name</th>
                    <th>Last Name</th>
                    <th>Contact No</th>
                    <th>Email</th>
                    <th>Username</th>
                    <th>Admin Type</th>
                    <th>Action</th>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include 'comon/footer.php';?>