<?php
@session_start();
if(!isset($_SESSION['SESS_login']))
{
header("location: index.php");
}
include 'comon/header.php';
include 'comon/left.php';
include 'dbconfig.php';
?>
    <div id="main">
<div class="row">
<?php
        //////////// get_page_action and id start /////////
                if (!isset($_GET['cmd']))
                {
                $_GET['cmd'] = "";
                }
                if($_GET["cmd"]=="delete")
        {
        if (!isset($_GET['id']))
        {
        $_GET['id'] = "";
        }
        $id=$_GET['id'];
        
        
        $sql = "DELETE From generatepin WHERE id=$id";
        $result = mysql_query($sql);
    ?>

<div class="card-alert card gradient-45deg-green-teal">
    <div class="card-content white-text">
      <p>
         <i class="material-icons">check</i> PIN Deleted Successfully........... !
      </p>
    </div>
</div>

          <?php
                }
        //////////// get_page_action and id start /////////
?>      

    <div class="col s12">
      <div class="card">
        <div class="card-content">
          <h4 class="card-title">Manage Admin
          </h4>
          <div class="row">
            <div class="col s12">
              <table id="example" class="display">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>PIN</th>
                    <th>Use Of Vehicle</th>
                    <th>CATEGOTY</th>
                    <th>IS USED</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                	<tr>
                		<?php
$query4="SELECT * FROM generatepin order by id DESC";
$result4=mysql_query($query4);
$num4=mysql_numrows($result4);
$iiii=0;
while ($iiii < $num4) {
$Id=mysql_result($result4,$iiii,"id");
$pin=mysql_result($result4,$iiii,"pin");
$isused=mysql_result($result4,$iiii,"isused");
$category=mysql_result($result4,$iiii,"category");
$useofvehicle=mysql_result($result4,$iiii,"useofvehicle");


?>            
                             <td><?php echo $Id; ?></td>
               <td><?php echo $pin; ?></td>
               <td><?php echo $useofvehicle; ?></td>
                <td><?php echo $category; ?></td>
               <td><?php echo $isused; ?></td>
                           <td>
								<a href="editpin.php?id=<?php  echo $Id; ?>&cmd=edit"> <i class="material-icons dp48">border_color</i> </a> &nbsp;&nbsp;
								  <a href="managepin.php?id=<?php  echo $Id; ?>&cmd=delete" ><i class="material-icons dp48">delete</i> </a>
							</td>
                           
                        </tr>
        <?php
$iiii++;
}
?>          
                </tbody>
                <tfoot>
                  <tr>
                     <th>ID</th>
                    <th>PIN</th>
                    <th>CATEGOTY</th>
                    <th>IS USED</th>
                    <th>Action</th>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include 'comon/footer.php';?>