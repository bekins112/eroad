<?php
@session_start();
if(!isset($_SESSION['SESS_login']))
{
header("location: index.php");
}
include 'comon/header.php';
include 'comon/left.php';
include 'dbconfig.php';
?>
<!-- BEGIN: Page Main-->
<div id="main">
  <div class="row">
    <div class="content-wrapper-before gradient-45deg-indigo-purple"></div>
    <div class="breadcrumbs-dark pb-0 pt-4" id="breadcrumbs-wrapper">
      <!-- Search for small screen-->
      <div class="container">
 <?php

if(isset($_POST['submit'])) 
{


$sql2="update feesmaster set useofvehicle='$_POST[useofvehicle]'
,typeofvehicle='$_POST[typeofvehicle]',fees='$_POST[fees]',category='$_POST[category]'
 WHERE id=".$_GET['id']." ";  
  
$result2 = mysql_query($sql2);
?>

<div class="card-alert card gradient-45deg-green-teal">
    <div class="card-content white-text">
      <p>
         <i class="material-icons">check</i> Fees Updated Successfully........... !
      </p>
    </div>
</div>

<?php
}
?> 

<?php
$GetPhotoSQL ="SELECT * FROM feesmaster WHERE id = ".$_GET['id']." LIMIT 1";
$GetPhotoResult = mysql_query($GetPhotoSQL);
$GetPhotoRow = mysql_fetch_array($GetPhotoResult);

?>
</div>
    </div>
    <div class="col s12">
      <div class="container">
        <!-- Input Fields -->
        <div class="row">
          <div class="col s12">
            <div id="input-fields" class="card card-tabs">
              <div class="card-content">
                <div class="card-title">
                  <div class="row">
                    <div class="col s12 m6 l10">
                      <h4 class="card-title">EDIT FEES</h4>
                    </div>
                  </div>
                </div>
                <div id="view-input-fields">
                  <div class="row">
                    <div class="col s12">
                      <form  method="post" action="">
                        <div class="col m6 s12">
                          <div class="input-field col s12">
                           <select class="form-control" name="category" required>
                                <option value="">Choose your option</option>
                                <option value="Vehicle Licence" <?php if($GetPhotoRow['category'] == "Vehicle Licence") echo "selected"; ?>>Vehicle Licence</option>
                                <option value="Road Worthiness" <?php if($GetPhotoRow['category'] == "Road Worthiness") echo "selected"; ?>>Road Worthiness</option>

                                <option value="Insurance" <?php if($GetPhotoRow['category'] == "Insurance") echo "selected"; ?>>Insurance</option>
                                <option value="Hackney Permit" <?php if($GetPhotoRow['category'] == "Hackney Permit") echo "selected"; ?>>Hackney Permit</option>
                                <option value="Tipper/Trailer Permit" <?php if($GetPhotoRow['category'] == "Tipper/Trailer Permit") echo "selected"; ?>>Tipper/Trailer Permit</option>
                                <option value="Number Plate" <?php if($GetPhotoRow['category'] == "Number Plate") echo "selected"; ?>>Number Plate</option>
                          </select>
                            <label for="password">Select Category</label>
                          </div>
                        </div>
                        <div class="col m6 s12">
                          <div class="input-field col s12">
                            <select class="form-control" name="useofvehicle" required>
                              <option value="">Choose your option</option>
                              <option value="Private" <?php if($GetPhotoRow['useofvehicle'] == "Private") echo "selected"; ?>>Private</option>
                              <option value="Commercial" <?php if($GetPhotoRow['useofvehicle'] == "Commercial") echo "selected"; ?>>Commercial</option>
                            </select>
                            <label for="password">Use of Vehicle</label>
                          </div>
                        </div>
                        <div class="col m6 s12">
                          <div class="input-field col s12">
                              <select class="form-control" name="typeofvehicle" required>
                                   <option value="">Choose your option</option>
                                   <option value="Motorcycle/Tricycle" <?php if($GetPhotoRow['typeofvehicle'] == "Motorcycle/Tricycle") echo "selected"; ?>>Motorcycle/Tricycle</option>
                                  <option value="Motorcycle/Tricycle" <?php if($GetPhotoRow['typeofvehicle'] == "Motorcycle/Tricycle") echo "selected"; ?>>Motorcycle/Tricycle</option>
                                   <option value="Car" <?php if($GetPhotoRow['typeofvehicle'] == "Car") echo "selected"; ?>>Car</option>

                                   <option value="Bus/SUV/Jeep" <?php if($GetPhotoRow['typeofvehicle'] == "Bus/SUV/Jeep") echo "selected"; ?>>Bus/SUV/Jeep</option>

                                   <option value="Tipper/Trailer" <?php if($GetPhotoRow['typeofvehicle'] == "Tipper/Trailer") echo "selected"; ?>>Tipper/Trailer</option>

                                 
                              </select>
                            <label for="password">Type of Vehicle</label>
                          </div>
                        </div>
                       <div class="col m6 s12">
                          <div class="input-field col s12">
                            <input name="fees" id="password" type="text" required=""
                            value="<?php echo $GetPhotoRow['fees'];?>">
                            <label for="password">Service Charge</label>
                          </div>
                        </div>
                  <button class="btn mb-1 waves-effect waves-light" type="submit" name="submit">Submit  
                    <i class="material-icons right">send</i></button>
                      </form>
                    </div>
                  </div>
                </div>
                
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="content-overlay"></div>
    </div>
  </div>
</div>
<!-- END: Page Main-->
<?php include 'comon/footer.php';?>