<?php
@session_start();
if(!isset($_SESSION['SESS_login']))
{
header("location: index.php");
}
include 'comon/header.php';
include 'comon/left.php';
include 'dbconfig.php';
 ?>

    <!-- BEGIN: Page Main-->
    <div id="main">


        <div class="row">


         <div class="col s12 m6 l6 xl3">
            <?php
            $number ="SELECT count(*) as totalnumber FROM preregistration";
            $numberResult = mysql_query($number);
            $numberRow = mysql_fetch_array($numberResult);
            ?>
            <div class="card gradient-45deg-light-blue-cyan gradient-shadow min-height-100 white-text animate fadeLeft">
               <div class="padding-4">
                  <div class="row">
                        <i class="material-icons background-round mt-5">add_shopping_cart</i>
                        <p>Total Plate Number Generated</p>
                        <h5 class="mb-0 white-text"><?php echo $numberRow['totalnumber'];?></h5>
                  </div>
               </div>
            </div>
         </div>
         <div class="col s12 m6 l6 xl3">
             <?php
            $usednumber ="SELECT count(*) as usedtotalnumber FROM preregistration where IsUsed=1";
            $usedNumberResult = mysql_query($usednumber);
            $NumberRow = mysql_fetch_array($usedNumberResult);
            ?>
            <div class="card gradient-45deg-red-pink gradient-shadow min-height-100 white-text animate fadeLeft">
               <div class="padding-4">
                  <div class="row">
                        <i class="material-icons background-round mt-5">perm_identity</i>
                        <p>Total Plate Number Used</p>
                        <h5 class="mb-0 white-text"><?php echo $NumberRow['usedtotalnumber'];?></h5>
                  </div>
               </div>
            </div>
         </div>
         <div class="col s12 m6 l6 xl3">
            <?php
            $pin ="SELECT count(*) as totalpin FROM generatepin";
            $PINResult = mysql_query($pin);
            $PinRow = mysql_fetch_array($PINResult);
            ?>
            <div class="card gradient-45deg-light-blue-cyan gradient-shadow min-height-100 white-text animate fadeLeft">
               <div class="padding-4">
                  <div class="row">
                        <i class="material-icons background-round mt-5">add_shopping_cart</i>
                        <p>Total PIN Generated</p>
                        <h5 class="mb-0 white-text"><?php echo $PinRow['totalpin'];?></h5>
                  </div>
               </div>
            </div>
         </div>
         <div class="col s12 m6 l6 xl3">
             <?php
            $usedpin ="SELECT count(*) as totalpin FROM generatepin where isused=1";
            $usedPINResult = mysql_query($usedpin);
            $UsedPinRow = mysql_fetch_array($usedPINResult);
            ?>

            <div class="card gradient-45deg-red-pink gradient-shadow min-height-100 white-text animate fadeLeft">
               <div class="padding-4">
                  <div class="row">
                        <i class="material-icons background-round mt-5">perm_identity</i>
                        <p>Total PIN Used</p>
                        <h5 class="mb-0 white-text"><?php echo $UsedPinRow['totalpin'];?></h5>
                  </div>
               </div>
            </div>
         </div>
         <div class="col s12 m6 l6 xl3">
             <?php
            $usedreg ="SELECT count(*) as totalregistration FROM vehiclelicense";
            $RegResult = mysql_query($usedreg);
            $RegRow = mysql_fetch_array($RegResult);
            ?>

            <div class="card gradient-45deg-amber-amber gradient-shadow min-height-100 white-text animate fadeRight">
               <div class="padding-4">
                  <div class="row">
                        <i class="material-icons background-round mt-5">timeline</i>
                        <p>Total Registration</p>
                        <h5 class="mb-0 white-text"><?php echo $RegRow['totalregistration'];?></h5>
                  </div>
               </div>
            </div>
         </div>
         <div class="col s12 m6 l6 xl3">
             <?php
            $usedrenewal ="SELECT count(*) as totalrenewal FROM renewal";
            $renewalResult = mysql_query($usedrenewal);
            $renewalRow = mysql_fetch_array($renewalResult);
            ?>
            <div class="card gradient-45deg-green-teal gradient-shadow min-height-100 white-text animate fadeRight">
               <div class="padding-4">
                  <div class="row">
                        <i class="material-icons background-round mt-5">attach_money</i>
                        <p>Total Renewal</p>
                        <h5 class="mb-0 white-text"><?php echo $renewalRow['totalrenewal'];?></h5>
                  </div>
               </div>
            </div>
         </div>




      </div>


    </div>
    <!-- END: Page Main-->



<?php include 'comon/footer.php';?>
