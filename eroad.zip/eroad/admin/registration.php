<?php
@session_start();
if(!isset($_SESSION['SESS_login']))
{
header("location: index.php");
}
include 'comon/header.php';
include 'comon/left.php';
include 'dbconfig.php';
?>
<!-- BEGIN: Page Main-->
<div id="main">
  <div class="row">


 <?php
if (!isset($_GET['cmd']))
{
$_GET['cmd'] = "";
}
if($_GET["cmd"]=="success")
{
date_default_timezone_set('Africa/Lagos');
$dt=date("Y-m-d");
$name=$_GET['name'];
$registrationdate=$_GET['registrationdate'];
$registrationno=$_GET['registrationno'];

$address=$_GET['address'];
$phonenumber=$_GET['phonenumber'];
$email=$_GET['email'];
$useofvehicle=$_GET['useofvehicle'];
$typeofvehicle=$_GET['typeofvehicle'];
$paymentoption=$_GET['paymentoption'];
$pinnumber=$_GET['pinnumber'];
$amount=$_GET['amount'];
$duedate=$_GET['duedate'];
$chassissno=$_GET['chassissno'];
$typesofpayment=$_GET['typesofpayment'];


//print_r($typesofpayment);exit();

$date = str_replace('/', '-', $duedate );
$duedate1 = date("Y-m-d", strtotime($date));


	$sql2="INSERT INTO vehiclelicense (name,registrationdate,registrationno,address,phonenumber,email,useofvehicle,typeofvehicle,paymentoption,pinnumber,amount,duedate,chassissno,typesofpayment) 
VALUES ('$name','$registrationdate','$registrationno','$address','$phonenumber','$email','$useofvehicle','$typeofvehicle','$paymentoption','$pinnumber','$amount','$duedate1','$chassissno','$typesofpayment')";
//print_r($sql2);		   
$result2 = mysql_query($sql2);
$last_id=mysql_insert_id();

$typesofpayment=explode(",",$typesofpayment);
foreach($typesofpayment as $value){
  $GetPhotoSQL ="SELECT fees FROM feesmaster WHERE category = '$value' and useofvehicle='$useofvehicle' 
  and typeofvehicle='$typeofvehicle'";
  $GetPhotoResult = mysql_query($GetPhotoSQL);
  $GetPhotoRow = mysql_fetch_array($GetPhotoResult);

  //echo $GetPhotoRow['fees'];
  $fees=$GetPhotoRow['fees'];
  $sql2="INSERT INTO registrationtypesofpayment (reg_id,registrationno,useofvehicle,typeofvehicle,typesofpayment
  ,amount,registrationdate) 
VALUES ('$last_id','$registrationno','$useofvehicle','$typeofvehicle','$value','$fees',
'$registrationdate')";
//print_r($sql2);      
$result2 = mysql_query($sql2);

}
//exit();
	$sql4="INSERT INTO vehiclelicensedetails (registrationdate,duedate,registrationno,paymentoption,pinnumber,amount) 
VALUES ('$registrationdate','$duedate1','$registrationno','$paymentoption','$pinnumber','$amount')";
//print_r($sql4);		   
$result4 = mysql_query($sql4);


$sql3="update preregistration set IsUsed='1' WHERE PreRegistrationNo='$registrationno'"; 	
//print_r($sql3);	
$result3 = mysql_query($sql3);
if($pinnumber!='')
{
$sql4="update generatepin set isused='1' WHERE pin='$pinnumber'"; 	
//print_r($sql3);	
$result4 = mysql_query($sql4);
}

$sql5="INSERT INTO vehiclelicense_receiptno (registrationno) 
VALUES ('$registrationno')";
$result4 = mysql_query($sql5);

/*require('textlocal.class.php');
$textlocal = new Textlocal('bekinsmart@gmail.com', '5D7kAMyB86CJGg*');
$numbers = array($phonenumber);
$sender = 'EasyTax';
$message = 'Congratulation! Vehicle Registration for {$registrationno} successful 
valid till {$duedate1}. Your Vehicle Documents will be made available soonest';
$result = $textlocal->sendSms($numbers, $message, $sender);*/

?>
<!-- <script> window.open("Receipt/vehiclelicense.php?registrationno=<?php Print $registrationno;?>"); </script>  -->
<!-- <script> location.replace("registration.php?status=success"); </script> -->
<script> location.replace("thankyou.php?status=registration&amount=<?php Print $amount;?>&pmode=<?php Print $paymentoption;?>"); </script>

<!-- <script> location.replace("thankyou.php?status=registration&registrationno=<?php Print $registrationno;?>"); </script> -->

 <?php
 }
if (!isset($_GET['status']))
{
$_GET['status'] = "";
}
if($_GET["status"]=="success")
{
?>

<div class="card-alert card gradient-45deg-green-teal">
    <div class="card-content white-text">
      <p>
         <i class="material-icons">check</i> Vehicle Registration Successful
      </p>
    </div>
</div>

<?php
}

?>		
    <div class="content-wrapper-before gradient-45deg-indigo-purple"></div>
    <div class="breadcrumbs-dark pb-0 pt-4" id="breadcrumbs-wrapper">
      <!-- Search for small screen-->
      <div class="container">
        
      </div>
    </div>
    <div class="col s12">
      <div class="container">
        
        <!-- Input Fields -->
        <div class="row">
          <div class="col s12">
            <div id="input-fields" class="card card-tabs">
              <div class="card-content">
                <div class="card-title">
                  <div class="row">
                    <div class="col s12 m6 l10">
                      <h4 class="card-title">REGISTRATION</h4>
                    </div>
                    
                  </div>
                </div>
                <div id="view-input-fields">
                  <div class="row">
                    <div class="col s12">
                      
                      <form  method="post" action="pay.php">
                        <div class="col s12">
                          <div class="input-field col m6 s12">
                            <input placeholder="Placeholder" id="date"  type="date" name="registrationdate" onchange="getdate()" required=""
                            max="<?php echo date('Y-m-d'); ?>" min="<?php echo date('Y-m-d'); ?>">
                            <!--  <input type="date" id="datemax" name="datemax" max="2020-07-18" min="2020-07-18"> -->
                            <label for="first_name1">Registration Date </label>
                          </div>
                          <div class="input-field col m6 s12" style="visibility: hidden;">
                            <select  name="registrationno" >
                              <option value="" disabled selected>Choose your option</option>
                             <?php 
                              $query4="SELECT * FROM preregistration where IsUsed=0 ORDER BY id ASC";
                              $result4=mysql_query($query4);
                              $num4=mysql_numrows($result4);
                              $iiii=0;
                              while ($iiii < $num4) {
                              
                              $projects_id4=mysql_result($result4,$iiii,"PreRegistrationNo");
                              $projects_name4=mysql_result($result4,$iiii,"PreRegistrationNo");
                              
                              ?>
                              
                              <option value="<?php echo $projects_id4; ?>"><?php echo $projects_name4; ?></option>
                              <?php 
                              $iiii++;
                              }
                              ?>
                            </select>
                            <label for="last_name">Select Plate Number</label>
                          </div>
                        </div>
                        
                        <div class="col m6 s12">
                          <div class="input-field col s12">
                            <input id="password" type="text" name="name" required="">
                            <label for="password">Name of Owner</label>
                          </div>
                        </div>
                        <div class="col m6 s12">
                          <div class="input-field col s12">
                            <input id="email3" type="text"  name="phonenumber" required="">
                            <label for="email3">Phone No of Owner </label>
                          </div>
                        </div>
                        <div class="col m12 s12">
                          <div class="input-field col s12">
                            <textarea id="icon_prefix2" name="address" required="" class="materialize-textarea" ></textarea>
                            <label for="icon_prefix2">Address of Owner</label>
                          </div>
                        </div>
                        <div class="col m6 s12">
                          <div class="input-field col s12">
                            <input id="password" type="email" name="email" required="">
                            <label for="password">Email</label>
                          </div>
                        </div>
                        <div class="col m6 s12">
                          <div class="input-field col s12">
                            <input onblur="check_chassiss()" id="chassiss" type="text" required="" name="chassissno">
                            <label for="email3">Chassiss No </label>
                            <div style="color:red;font-size:20px;" id="chassissno" class="chassissno"></div> 
                          </div>
                        </div>
                        <div class="input-field col m4 s12">
                          <select id="useofvehicle" name="useofvehicle" onchange="getdate()" required="">
                            <option value="" disabled selected>Choose your option</option>
                        
                          <option value="Private">Private</option>
                          <option value="Commercial">Commercial</option>
                          </select>
                          <label for="last_name">Use of Vehicle</label>
                        </div>
                        <div class="input-field col m4 s12">
                          <select id="typeofvehicle" name="typeofvehicle" required="">
                            <option value="" disabled selected>Choose your option</option>
                           
                          <option value="Motorcycle/Tricycle">Motorcycle/Tricycle</option>
                          <option value="Car">Car</option>
                          <option value="Bus/SUV/Jeep">Bus/SUV/Jeep</option>
                         <option value="Tipper/Trailer">Tipper/Trailer</option>
                          
                          </select>
                          <label for="last_name">Type of Vehicle</label>
                        </div>
                        <div class="col m4 s12">
                          <div class="input-field col s12">
                            <input  type="text" name="duedate" id="duedate" readonly="">
                            <label for="email3">Expiry Date </label>
                          </div>
                        </div>
                        <div id="view-checkboxes">
                          <label for="payment" style="color:#6d6969;font-weight: bold;">Type of Payment</label>
                          <div class="input-field col s12">
                            <p class="mb-1">
                              <label>
                                <input class="payment" type="checkbox" value="Vehicle Licence" id="payment1" name="typesofpayment[]" />
                                <span>Vehicle Licence</span>
                              </label>
                            </p>
                            <p class="mb-1">
                              <label>
                                <input class="payment" type="checkbox" value="Road Worthiness" id="payment2" name="typesofpayment[]" />
                                <span>Road Worthiness</span>
                              </label>
                            </p>
                            <p class="mb-1">
                              <label>
                                <input class="payment" type="checkbox" value="Hackney Permit"  id="payment3" name="typesofpayment[]"/>
                                <span>Hackney Permit</span>
                              </label>
                            </p>
                            <p class="mb-1">
                              <label>
                                <input class="payment" type="checkbox" value="Insurance" id="payment4" name="typesofpayment[]" />
                                <span>Insurance </span>
                              </label>
                            </p>
                             <p class="mb-1">
                              <label>
                                <input class="payment" type="checkbox" value="Tipper/Trailer Permit" id="payment5" name="typesofpayment[]" />
                                <span>Tipper/Trailer Permit </span>
                              </label>
                            </p>
                            <p class="mb-1">
                              <label>
                                <input class="payment" type="checkbox" value="Number Plate" id="payment6" name="typesofpayment[]" />
                                <span>Number Plate </span>
                              </label>
                            </p>
                          </div>
                        </div>
                        <div class="input-field col m4 s12">
                          <select id="paymenttype" onchange="checkFilled();" name="paymentoption" required="">
                            <option value="" disabled selected>Choose your option</option>
                              <option value="Online">Online</option>
                              <option value="PIN">PIN</option>
                          </select>
                          <label for="last_name">Payment Option</label>
                        </div>
                        <div class="col m4 s12">
                          <div class="input-field col s12">
                            <input onblur="check_pin()" type="text" class="form-control" name="pinnumber" id="pin" 
                              placeholder="PIN Number " readonly >
                             <div style="color:red;font-size:20px;" id="uname_response" class="response"></div> 
                            <label for="email3">PIN Number  </label>
                          </div>
                        </div>
                        <div class="col m4 s12">
                          <div class="input-field col s12">
                            <input id="amount" type="text" name="registrationfee" required="" readonly="">
                            <label for="email3">Amount </label>
                          </div>
                        </div>
                     <div class="col m12 s12"> 
                  <button class="btn mb-1 waves-effect waves-light" type="submit" name="submit">Submit  
                    <i class="material-icons right">send</i></button>
                  </div>
                       
                      </form>
                    </div>
                  </div>
                </div>
                
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="content-overlay"></div>
    </div>
  </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script> 

<script>
    $(document).ready(function() {

      $('#useofvehicle').on('change',function(){
    var useofvehicle = $(this).val();  
    var typeofvehicle=$("#typeofvehicle").val();// value in field email
    var payment_type = [];
            $.each($("input[class='payment']:checked"), function(){
                payment_type.push("'"+$(this).val()+"'");
            });
            if(payment_type.length!=0){ payment_type=payment_type}else { payment_type="'Prime'";}
    $.ajax({
     type :'GET',
        dataType:'json',
    data:{useofvehicle: useofvehicle,typeofvehicle: typeofvehicle,paymenttype:payment_type},
        url : 'codegenrate.php?useofvehicle='+useofvehicle+'&typeofvehicle='+typeofvehicle+'&paymenttype='+payment_type,
        success : function(result){
    $('#amount').val(result['fees']);
    }
   });
  }); 

  $(".payment").click(function(){
    //alert();
        var useofvehicle =$("#useofvehicle").val();// value in field email
        var typeofvehicle=$("#typeofvehicle").val();// value in field email
        var payment_type = [];
        $.each($("input[class='payment']:checked"), function(){
            payment_type.push("'"+$(this).val()+"'");
        });
        if(payment_type.length!=0){ payment_type=payment_type}else { payment_type="'Prime'";}
          $.ajax({
         type :'GET',
            dataType:'json',
           url : 'codegenrate.php?useofvehicle='+useofvehicle+'&typeofvehicle='+typeofvehicle+'&paymenttype='+payment_type,
            success : function(result){
            $('#amount').val(result['fees']);
            M.updateTextFields();
        }
        });
  });


  $('#typeofvehicle').on('change',function(){
  var typeofvehicle = $(this).val();  
  var useofvehicle=$("#useofvehicle").val();// value in field email
  var payment_type = [];
        $.each($("input[class='payment']:checked"), function(){
            payment_type.push("'"+$(this).val()+"'");
        });
        if(payment_type.length!=0){ payment_type=payment_type}else { payment_type="'Prime'";}
  $.ajax({
   type :'GET',
      dataType:'json',
 // data:{country_id: countryID,typeofvehicle: typeofvehicle,category:category},
     url : 'codegenrate.php?useofvehicle='+useofvehicle+'&typeofvehicle='+typeofvehicle+'&paymenttype='+payment_type,
      success : function(result){
  $('#amount').val(result['fees']);
  }

  });
  }); 


    });
</script>



<script>
$(document).ready(function(){
    $('#paymenttype').on('change',function(){
        var paymenttype = $(this).val();  
    if(paymenttype=="Online")
  {
     $('#pin').prop('required', false);
    document.getElementById("pin").readOnly = true; 
  }
  else
  {
    $('#pin').prop('required', true);
  document.getElementById("pin").readOnly = false; 
  }
    }); 
 }); 
function getdate() {
var tt1 = document.getElementById('useofvehicle').value;
if(tt1=='Private')
{
    var tt = document.getElementById('date').value;
    //alert(tt);
    var date = new Date(tt);
//alert(date);
    var newdate = new Date(date);
    newdate.setDate(newdate.getDate() + 366);
    var dd = newdate.getDate();
    var mm = newdate.getMonth() + 1;
    var y = newdate.getFullYear();
   // alert(newdate);
    var someFormattedDate = dd + '/' + mm + '/' + y;
    document.getElementById('duedate').value = someFormattedDate;
    M.updateTextFields();
  //$('select').formSelect();
} 
else if(tt1=='Commercial')
{
    var tt = document.getElementById('date').value;
    var date = new Date(tt);
    var newdate = new Date(date);
    newdate.setDate(newdate.getDate() + 183);
    var dd = newdate.getDate();
    var mm = newdate.getMonth() + 1;
    var y = newdate.getFullYear();
    var someFormattedDate = dd + '/' + mm + '/' + y;
    document.getElementById('duedate').value = someFormattedDate;
}
}
</script>   
<script type="text/javascript">
function check_pin(){

var pin=$("#pin").val();// value in field email
var useofvehicle=document.getElementById('useofvehicle').value;
var paymenttype=document.getElementById('paymenttype').value;
//alert(paymenttype);
if(paymenttype=='PIN')
{

$.ajax({
    type:'GET',
     url : 'checkpinexists.php?pin='+pin+'&useofvehicle='+useofvehicle,
     // url:'checkpinexists.php',// put your real file name 
        //data:{pin: pin},
    //data:{pin: pin,useofvehicle: useofvehicle},
        success:function(msg){
    if(msg>0)
    {
     $("#uname_response").hide();
    }
    else
    {
     $("#uname_response").show();
     $("#uname_response").html("<span class='not-exists'>* PIN Not Available.</span>");
         //alert(msg); // your message will come here.  
     $('#pin').val(''); //txtID is textbox ID
    // $("#pin").focus();
    }   
        }
 });
}
}
</script>     
<script>
function validateForm() {
var paymentoption=document.forms["myForm"]["paymentoption"].value;
if(paymentoption=='PIN')
{
  var x = document.forms["myForm"]["pinnumber"].value;
  if (x == "") {
    alert("Please Enter PIN");
  $('#pin').val(''); //txtID is textbox ID
  //$("#pin").focus();
    return false;
  }
  }
} 
</script>  


<script type="text/javascript">
function check_chassiss(){

var chassissno=$("#chassiss").val();// value in field email

$.ajax({
    type:'GET',
     url : 'checkchassissnoexists.php?chassissno='+chassissno,
     // url:'checkpinexists.php',// put your real file name 
        //data:{pin: pin},
    //data:{pin: pin,useofvehicle: useofvehicle},
        success:function(msg){
    if(msg>0)
    {
       $("#chassissno").show();
       $("#chassissno").html("<span class='not-exists'>* Chassiss No All Ready Exists.</span>");
       $('#chassiss').val(''); //txtID is textbox ID
    }
    else
    {
     $("#chassissno").hide();
    // $("#pin").focus();
    }   
        }
 });
}
</script>  
<!-- END: Page Main-->
<?php include 'comon/footer.php';?>