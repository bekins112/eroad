<?php
@session_start();
if(!isset($_SESSION['SESS_login']))
{
header("location: index.php");
}
include 'comon/header.php';
include 'comon/left.php';
include 'dbconfig.php';
?>
    <div id="main">
<div class="row">
 <?php
        //////////// get_page_action and id start /////////
        if (!isset($_GET['cmd']))
        {
        $_GET['cmd'] = "";
        }
        if($_GET["cmd"]=="delete")
        {
        if (!isset($_GET['id']))
        {
        $_GET['id'] = "";
        }
        $id=$_GET['id'];
        
        $sql0 = "SELECT * FROM vehiclelicense WHERE id=".$_GET['id'];"";
        $result0=mysql_query($sql0);
        $num0=mysql_numrows($result0);
        $i0=0;
        $registrationno=mysql_result($result0,$i0,"registrationno");

        $sql3="update preregistration set IsUsed='0' WHERE PreRegistrationNo='$registrationno'";  
        //print_r($sql3); 
        $result3 = mysql_query($sql3);
        
        $sql = "DELETE From vehiclelicense WHERE id=$id";
        $result = mysql_query($sql);

        $sql1 = "DELETE From vehiclelicensedetails  WHERE registrationno=$registrationno'"; 
        $result1 = mysql_query($sql1);
    ?>

<div class="card-alert card gradient-45deg-green-teal">
    <div class="card-content white-text">
      <p>
         <i class="material-icons">check</i> 
Vehicle License Registration Details Deleted Successfully........... !

      </p>
    </div>
</div>

          <?php
                }
        
        //////////// get_page_action and id start /////////
?>   

    <div class="col s12">
      <div class="card">
        <div class="card-content">
          <h4 class="card-title">Manage Vehicle Registration Details
          </h4>
          <div class="row">
            <div class="col s12">
               <table class="table display nowrap table-striped table-bordered scroll-horizontal">
                <thead>
                  <tr>
                    <th>Id</th>
                    <th>Registration Date</th>
                    <th>Expiry Date</th>
                    <th>Plate Number</th>   
                    <th>Chassi No</th>          
                    <th>Name</th>     
                    <th>Phone No</th>     
                    <th>Use Of Vehicle</th>  
                    <th>Type Of Vehicle</th>     
                    <th>Types Of Payment</th>     
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                	<tr>
                		<?php
$query4="SELECT * FROM vehiclelicense order by id DESC";
$result4=mysql_query($query4);
$num4=mysql_numrows($result4);
$iiii=0;
while ($iiii < $num4) {
$Id=mysql_result($result4,$iiii,"id");
$registrationdate=mysql_result($result4,$iiii,"registrationdate");
$duedate=mysql_result($result4,$iiii,"duedate");
$registrationno=mysql_result($result4,$iiii,"registrationno");
$name=mysql_result($result4,$iiii,"name");
$phonenumber=mysql_result($result4,$iiii,"phonenumber");
$useofvehicle=mysql_result($result4,$iiii,"useofvehicle");
$typeofvehicle=mysql_result($result4,$iiii,"typeofvehicle");
$chassissno=mysql_result($result4,$iiii,"chassissno");
$typesofpayment=mysql_result($result4,$iiii,"typesofpayment");
?>            
                        <td><?php echo $Id; ?></td>
                        <td><?php echo $registrationdate; ?></td>
                        <td><?php echo $duedate; ?></td>
                       <td><?php echo $registrationno; ?></td>
                        <td><?php echo $chassissno; ?></td>
                       <td><?php echo $name; ?></td>
                       <td><?php echo $phonenumber; ?></td>
                       <td><?php echo $useofvehicle; ?></td>
                       <td><?php echo $typeofvehicle; ?></td>
                      
                       <td><?php echo $typesofpayment; ?></td>
                           <td>
								<a href="editregistration.php?id=<?php  echo $Id; ?>&cmd=edit"> <i class="material-icons dp48">border_color</i> </a> &nbsp;&nbsp;
								  <a href="manage-vehicle-registration.php?id=<?php  echo $Id; ?>&cmd=delete" ><i class="material-icons dp48">delete</i> </a>
							</td>
                           
                        </tr>
        <?php
$iiii++;
}
?>          
                </tbody>
                <tfoot>
                  <tr>
                    <th>Id</th>
                    <th>Registration Date</th>
                    <th>Expiry Date</th>
                    <th>Registration No</th>   
                    <th>Chassi No</th>          
                    <th>Name</th>     
                    <th>Phone No</th>     
                    <th>Use Of Vehicle</th>  
                    <th>Type Of Vehicle</th>     
                    <th>Types Of Payment</th>     
                    <th>Actions</th>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>



  
<?php include 'comon/footer.php';?>