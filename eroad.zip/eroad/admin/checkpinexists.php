<?php

include "dbconfig.php";

/* Get username */
$pin = $_GET['pin'];
$useofvehicle = $_GET['useofvehicle'];

/* Query */
$query = "select count(*) as cntUser from generatepin where pin='".$pin."' and useofvehicle='".$useofvehicle."' and isused=0";
//print_r($query);exit();
$result = mysql_query($query);
$row = mysql_fetch_array($result);
$count = $row['cntUser'];

echo $count;
?>