<?php

require_once 'ps_package/autoload.php';

$secret_key = 'sk_test_7b472e941471edbb8b0dc01147a2b55ff122ecf8';

$paystack = new \Yabacon\Paystack($secret_key);

$reference = isset($_GET['reference']) ? $_GET['reference'] : '';
if(!$reference){
    die('No reference supplied');
}

// initiate the Library's Paystack Object
$paystack = new Yabacon\Paystack($secret_key);
try
{
    // verify using the library
    $tranx = $paystack->transaction->verify([
        'reference'=>$reference, // unique to transactions
    ]);
} catch(\Yabacon\Paystack\Exception\ApiException $e){
    print_r($e->getResponseObject());
    die($e->getMessage());
}

if ('success' === $tranx->data->status) {

       ?>		
 <script> location.replace("registration.php?&cmd=success&name=<?php Print $_GET['name'];?>&registrationdate=<?php Print $_GET['registrationdate'];?>&registrationno=<?php Print $_GET['registrationno'];?>&address=<?php Print $_GET['address'];?>&phonenumber=<?php Print $_GET['phonenumber'];?>&email=<?php Print $_GET['email'];?>&useofvehicle=<?php Print $_GET['useofvehicle'];?>&typeofvehicle=<?php Print $_GET['typeofvehicle'];?>&paymentoption=<?php Print $_GET['paymentoption'];?>&pinnumber=<?php Print $_GET['pinnumber'];?>&amount=<?php Print $_GET['amount'];?>&duedate=<?php Print $_GET['duedate'];?>&chassissno=<?php Print $_GET['chassissno'];?>&typesofpayment=<?php Print $_GET['typesofpayment'];?>"); </script>
 <?php

}