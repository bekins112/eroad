<?php
@session_start();
if(!isset($_SESSION['SESS_login']))
{
header("location: index.php");
}
include 'comon/header.php';
include 'comon/left.php';
include 'dbconfig.php';
?>
<!-- BEGIN: Page Main-->
<div id="main">
  <div class="row">
    <div class="content-wrapper-before gradient-45deg-indigo-purple"></div>
    <div class="breadcrumbs-dark pb-0 pt-4" id="breadcrumbs-wrapper">
      <!-- Search for small screen-->
      <div class="container">
   <?php

if(isset($_POST['submit'])) 
{


$sql2="update generatepin set pin='$_POST[pin]', category='$_POST[category]', useofvehicle='$_POST[useofvehicle]'
 WHERE id=".$_GET['id']." ";           
$result2 = mysql_query($sql2);
?>

<div class="card-alert card gradient-45deg-green-teal">
    <div class="card-content white-text">
      <p>
         <i class="material-icons">check</i> PIN Updated Successfully........... !
      </p>
    </div>
</div>

<?php
}
?> 
<?php
$GetPhotoSQL ="SELECT * FROM generatepin WHERE id = ".$_GET['id']." LIMIT 1";
$GetPhotoResult = mysql_query($GetPhotoSQL);
$GetPhotoRow = mysql_fetch_array($GetPhotoResult);
?>     
</div>
    </div>
    <div class="col s12">
      <div class="container">
        <!-- Input Fields -->
        <div class="row">
          <div class="col s12">
            <div id="input-fields" class="card card-tabs">
              <div class="card-content">
                <div class="card-title">
                  <div class="row">
                    <div class="col s12 m6 l10">
                      <h4 class="card-title">PIN MASTER</h4>
                    </div>
                  </div>
                </div>
                <div id="view-input-fields">
                  <div class="row">
                    <div class="col s12">
                      <form  method="post" action="">
                        <div class="col m6 s12">
                          <div class="input-field col s12">
                            <input name="pin" id="password" type="text" required=""
                            value="<?php echo $GetPhotoRow['pin'];?>">
                            <label for="password">Generate PIN</label>
                          </div>
                        </div>
                         <div class="col m6 s12">
                          <div class="input-field col s12">
                            <select class="form-control" name="useofvehicle" required>
                              <option value="">Choose your option</option>
                             <!--  <option value="Private" <?php if($GetPhotoRow['useofvehicle'] == "Private") echo "selected"; ?>>Private</option> -->
                              <option value="Commercial" <?php if($GetPhotoRow['useofvehicle'] == "Commercial") echo "selected"; ?>>Commercial</option>
                            </select>
                            <label for="password">Use of Vehicle</label>
                          </div>
                        </div>

                          <div class="col m12 s12">
                          <div class="input-field col s12">
                                  <select class="form-control" name="category" required>
                                    <option value="">Choose your option</option>
                 

                                    <option value="Commercial Motorcycle/Tricycle" <?php if($GetPhotoRow['category'] == "Commercial Motorcycle/Tricycle") echo "selected"; ?>>Commercial Motorcycle/Tricycle</option>
                                    <option value="Commercial Car" <?php if($GetPhotoRow['category'] == "Commercial Car") echo "selected"; ?>>Commercial Car</option>
                                    <option value="Commercial Bus/SUV/Jeep" <?php if($GetPhotoRow['category'] == "Commercial Bus/SUV/Jeep") echo "selected"; ?>>VL+RW+HC+IN</option>
                                    <option value="Tipper/Trailer" <?php if($GetPhotoRow['category'] == "Tipper/Trailer") echo "selected"; ?>>Tipper/Trailer</option>
                                    
                                 </select>
                            <label for="password">Select Category</label>
                          </div>
                        </div>
                  <button class="btn mb-1 waves-effect waves-light" type="submit" name="submit">Submit  
                    <i class="material-icons right">send</i></button>
                      </form>
                    </div>
                  </div>
                </div>
                
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="content-overlay"></div>
    </div>
  </div>
</div>
<!-- END: Page Main-->
<?php include 'comon/footer.php';?>