<?php
@session_start();
if(!isset($_SESSION['SESS_login']))
{
header("location: index.php");
}
include 'comon/header.php';
include 'comon/left.php';
include 'dbconfig.php';
?>
<!-- BEGIN: Page Main-->
<div id="main">
  <div class="row">
    <div class="content-wrapper-before gradient-45deg-indigo-purple"></div>
    <div class="breadcrumbs-dark pb-0 pt-4" id="breadcrumbs-wrapper">
      <!-- Search for small screen-->
      <div class="container">
    
</div>
    </div>
    <div class="col s12">
      <div class="container">
        <!-- Input Fields -->
        <div class="row">
          <div class="col s12">
            <div id="input-fields" class="card card-tabs">
              <div class="card-content">
                <div class="card-title">
                  <div class="row">
                    <div class="col s12 m6 l10">
                      <h4 class="card-title">Reports</h4>
                    </div>
                  </div>
                </div>
                <div id="view-input-fields">
                  <div class="row">
                    <div class="col s12">
                      <form  method="get" action="">
                          <div class="input-field col s4">
                            <input placeholder="Placeholder" id="date" type="date" name="fromdate" required="">
                            <label for="first_name1">Registration Date </label>
                          </div>
                           <div class="input-field col s4">
                            <input placeholder="Placeholder" id="date" type="date" name="todate" required="">
                            <label for="first_name1">Registration Date </label>
                          </div>

                         
                          <div class="input-field col s4">
                             <select class="form-control" name="reporttype" required>
                                <option value="">Select Category</option>
                                <option value="ALL">ALL</option>
                                <option value="Vehicle Licence">Vehicle Licence</option>
                                <option value="Road Worthiness">Road Worthiness</option>
                                <option value="Hackney Permit">Hackney Permit</option>
                                <option value="Insurance">Insurance</option>
                           </select>
                            <label for="password">Select Category</label>
                          </div>
                        
                        
                     <button type="submit"  class="btn mb-1 waves-effect waves-light">Show Report 
                    <i class="material-icons right">send</i></button>
                      </form>
                    </div>
                  </div>

<?php
if (!isset($_GET['fromdate']))
{
$_GET['fromdate'] = "";
$_GET['todate'] = "";
$_GET['reporttype'] = "";
}
if($_GET["fromdate"]!="")
{
$fromdate=$_GET['fromdate'];
$todate=$_GET['todate'];
$reporttype=$_GET['reporttype'];
?>      
<?php if($_GET["reporttype"]!="ALL") 
{
?>
    <div class="row">
        <div class="col s12">
      <div class="card">
        <div class="card-content">
          <h4 class="card-title"><?php echo $_GET["reporttype"];?>
          </h4>
          <div class="row">
            <div class="col s12">
              <table id="example" class="display">
                <thead>
                  <tr>
                    <th>Registration No</th>
                    <th>Registration Date</th>
                    <th>Expiry Date</th>
                    <th>Name</th>     
                    <th>Phone Number</th>       
                    <th>Fees</th>                     
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <?php
$query4="SELECT r.registrationdate,v.duedate,r.registrationno,v.name,v.phonenumber,r.amount FROM registrationtypesofpayment r inner join vehiclelicense v on r.registrationno=v.registrationno 
 where v.registrationdate  between '".$_GET['fromdate']."' and '".$_GET['todate']."' and r.typesofpayment='$reporttype' order by r.id DESC";
$result4=mysql_query($query4);
$num4=mysql_numrows($result4);
$iiii=0;
while ($iiii < $num4) {
$registrationdate=mysql_result($result4,$iiii,"registrationdate");
$duedate=mysql_result($result4,$iiii,"duedate");
$registrationno=mysql_result($result4,$iiii,"registrationno");
$name=mysql_result($result4,$iiii,"name");
$phonenumber=mysql_result($result4,$iiii,"phonenumber");
$amount=mysql_result($result4,$iiii,"amount");

?>         
               <td><?php echo $registrationno; ?></td>
                <td><?php echo $registrationdate; ?></td>
               <td><?php echo $duedate; ?></td>
               <td><?php echo $name; ?></td>
               <td><?php echo $phonenumber; ?></td>
               <td><?php echo $amount; ?></td>
          </tr>
        <?php
$iiii++;
}
?>          
                </tbody>
                <tfoot>
                  <tr>
                      <th>Registration No</th>
                    <th>Registration Date</th>
                    <th>Expiry Date</th>
                    <th>Name</th>     
                    <th>Phone Number</th>       
                    <th>Fees</th>        
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
        </div>  
<?php
}
else if($_GET["reporttype"]=="ALL") 
{
?>
    <div class="row">
        <div class="col s12">
      <div class="card">
        <div class="card-content">
          <h4 class="card-title"><?php echo $_GET["reporttype"];?>
          </h4>
          <div class="row">
            <div class="col s12">
              <table id="example" class="display">
                <thead>
                  <tr>
                    <th>Registration No</th>
                    <th>Registration Date</th>
                    <th>Expiry Date</th>
                    <th>Name</th>     
                    <th>Phone Number</th>       
                    <th>Fees</th>                     
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <?php
$query4="SELECT r.registrationdate,v.duedate,r.registrationno,v.name,v.phonenumber,r.amount FROM registrationtypesofpayment r inner join vehiclelicense v on r.registrationno=v.registrationno 
 where v.registrationdate  between '".$_GET['fromdate']."' and '".$_GET['todate']."'  order by r.id DESC";
$result4=mysql_query($query4);
$num4=mysql_numrows($result4);
$iiii=0;
while ($iiii < $num4) {
$registrationdate=mysql_result($result4,$iiii,"registrationdate");
$duedate=mysql_result($result4,$iiii,"duedate");
$registrationno=mysql_result($result4,$iiii,"registrationno");
$name=mysql_result($result4,$iiii,"name");
$phonenumber=mysql_result($result4,$iiii,"phonenumber");
$amount=mysql_result($result4,$iiii,"amount");

?>         
               <td><?php echo $registrationno; ?></td>
                <td><?php echo $registrationdate; ?></td>
               <td><?php echo $duedate; ?></td>
               <td><?php echo $name; ?></td>
               <td><?php echo $phonenumber; ?></td>
               <td><?php echo $amount; ?></td>
          </tr>
        <?php
$iiii++;
}
?>          
                </tbody>
                <tfoot>
                  <tr>
                      <th>Registration No</th>
                    <th>Registration Date</th>
                    <th>Expiry Date</th>
                    <th>Name</th>     
                    <th>Phone Number</th>       
                    <th>Fees</th>        
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
        </div>  
<?php
}
}
?>
               


                </div>
                
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="content-overlay"></div>
    </div>
  </div>
</div>
<!-- END: Page Main-->
<?php include 'comon/footer.php';?>