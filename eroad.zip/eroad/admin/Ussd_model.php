<?php
Class Ussd_model extends CI_Model
{
	public function __construct()
	{
		$this->load->database();
	}
	
	public function get_registration($phoneNumber)
	{
		$this->db->select('*');	
		$this->db->from('registration');
		$where=array('phone_number'=>$phoneNumber);
		$this->db->where($where);
		$this->db->limit(1);
		$query	=	$this->db->get();
		return $query->row_array();
	}
	

}
