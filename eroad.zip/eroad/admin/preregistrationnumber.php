<?php
@session_start();
if(!isset($_SESSION['SESS_login']))
{
header("location: index.php");
}
include 'comon/header.php';
include 'comon/left.php';
include 'dbconfig.php';
?>
<!-- BEGIN: Page Main-->
<div id="main">
  <div class="row">
    <div class="content-wrapper-before gradient-45deg-indigo-purple"></div>
    <div class="breadcrumbs-dark pb-0 pt-4" id="breadcrumbs-wrapper">
      <!-- Search for small screen-->
      <div class="container">
  <?php

if(isset($_POST['submit'])) 
{

$No=$_POST['PreRegistrationNo'];
$query4="SELECT * FROM preregistration where PreRegistrationNo='$No'";
$result4=mysql_query($query4);
$num4=mysql_numrows($result4);
if($num4<=0)
{
$sql2="INSERT INTO preregistration (PreRegistrationNo) 
VALUES ('$_POST[PreRegistrationNo]')";
$result2 = mysql_query($sql2);

?>
<div class="card-alert card gradient-45deg-green-teal">
    <div class="card-content white-text">
      <p>
         <i class="material-icons">check</i>Plate Number Added Successfully........... !
      </p>
    </div>
</div>
<?php
}
else
{
  ?>
  <div class="card-alert card gradient-45deg-green-teal">
    <div class="card-content white-text">
      <p>
         <i class="material-icons">check</i>Plate Number Exists........... !
      </p>
    </div>
</div>
</div>
<?php
}
}
?>


</div>
    </div>
    <div class="col s12">
      <div class="container">
        <!-- Input Fields -->
        <div class="row">
          <div class="col s12">
            <div id="input-fields" class="card card-tabs">
              <div class="card-content">
                <div class="card-title">
                  <div class="row">
                    <div class="col s12 m6 l10">
                      <h4 class="card-title">Generate Plate Number</h4>
                    </div>
                  </div>
                </div>
                <div id="view-input-fields">
                  <div class="row">
                    <div class="col s12">
                      <form  method="post" action="">
                        <div class="col s12">
                          <div class="input-field col s12">
                            <input onblur="check_pin()" name="PreRegistrationNo" id="PreRegistrationNo" type="text"  required="">
                            <label for="password">Generate Plate Number</label>
                             <div style="color:red;font-size:20px;" id="uname_response" class="response"></div> 
                          </div>
                        </div>
                        
                       
                  <button class="btn mb-1 waves-effect waves-light" type="submit" name="submit">Save  
                    <i class="material-icons right">send</i></button>
                      </form>
                    </div>
                  </div>
                </div>
                
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="content-overlay"></div>
    </div>
  </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>   
<script type="text/javascript">
function check_pin(){
var PreRegistrationNo=$("#PreRegistrationNo").val();// value in field email

$.ajax({
    type:'post',
      url:'checkregisternumberexists.php',// put your real file name 
        //data:{pin: pin},
    data:{PreRegistrationNo: PreRegistrationNo},
        success:function(msg){
    if(msg>0)
    {
     
     $("#uname_response").show();
     $("#uname_response").html("<span class='not-exists'>* Plate Number Exists.</span>");
         //alert(msg); // your message will come here.  
     $('#PreRegistrationNo').val(''); //txtID is textbox ID
    // $("#pin").focus();
    }
    else
    {
     $("#uname_response").hide();
     
    }   
        }
 });
}
</script>  
<!-- END: Page Main-->
<?php include 'comon/footer.php';?>