

<?php include("dbconfig.php");
$paymenttype= $_GET['paymenttype'];
$useofvehicle= $_GET['useofvehicle'];
$typeofvehicle= $_GET['typeofvehicle'];


$mysqli = new mysqli($dbserver,$username,$password,$database);
//echo($zip1);
//die;

 $qry="SELECT IFNULL(sum(fees),0) as fees from feesmaster where  category in($paymenttype) and useofvehicle='$useofvehicle' and typeofvehicle='$typeofvehicle'";
 //echo $qry;exit();

 	  $result=mysqli_query($mysqli,$qry);
      $rowcount=mysqli_fetch_assoc($result);
echo json_encode($rowcount);


