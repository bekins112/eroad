<?php
            $payment_type='';
            foreach ($_POST['typesofpayment'] as $key => $typesofpayment) {
              $payment_type .= $typesofpayment.',';
            }
            $payment_type = rtrim($payment_type,',');
           
           // echo $payment_type;exit;

$paymentoption= $_POST['paymentoption'];
if($paymentoption=='Online')
{
require_once 'ps_package/autoload.php';

$secret_key = 'sk_test_7b472e941471edbb8b0dc01147a2b55ff122ecf8';

$paystack = new \Yabacon\Paystack($secret_key);


$trx = $paystack->transaction->initialize(
    [
        //'amount' => 20000, /* 200 naira */
		'amount' => $_POST['registrationfee']*100,
        //'email' => 'nameisbhavin69@gmail.com', /* CUSTOMER EMAIL */
		'email' => $_POST['email'],
		
        'callback_url' =>  'http://eroad.primetechnosoft.in/admin/verify.php?name='.$_POST['name'].'&registrationdate='.$_POST['registrationdate'].'&registrationno='.$_POST['registrationno'].'&address='.$_POST['address'].'&phonenumber='.$_POST['phonenumber'].'&email='.$_POST['email'].'&useofvehicle='.$_POST['useofvehicle'].'&typeofvehicle='.$_POST['typeofvehicle'].'&paymentoption='.$_POST['paymentoption'].'&pinnumber='.$_POST['pinnumber'].'&amount='.$_POST['registrationfee'].'&duedate='.$_POST['duedate'].'&chassissno='.$_POST['chassissno'].'&typesofpayment='.$payment_type, /* url ro verify the payment */
        'metadata' => json_encode([
            'account_type' => 'client'
        ])
    ]
);

if (!$trx->status) {
    exit($trx->message);
}

header('Location: ' . $trx->data->authorization_url);

exit();
}
else if($paymentoption=='PIN')
{
		
	?>		
 <script> location.replace("registration.php?&cmd=success&name=<?php Print $_POST['name'];?>&registrationdate=<?php Print $_POST['registrationdate'];?>&registrationno=<?php Print $_POST['registrationno'];?>&address=<?php Print $_POST['address'];?>&phonenumber=<?php Print $_POST['phonenumber'];?>&email=<?php Print $_POST['email'];?>&useofvehicle=<?php Print $_POST['useofvehicle'];?>&typeofvehicle=<?php Print $_POST['typeofvehicle'];?>&paymentoption=<?php Print $_POST['paymentoption'];?>&pinnumber=<?php Print $_POST['pinnumber'];?>&amount=<?php Print $_POST['registrationfee'];?>&duedate=<?php Print $_POST['duedate'];?>&chassissno=<?php Print $_POST['chassissno'];?>&typesofpayment=<?php Print $payment_type?>"); </script>
 <?php
	
}