<?php
//EDIT HERE
$dbserver = "localhost";
$username = "rizquad1_eroad1";
$password = "Best4m&you";
$database = "rizquad1_eroad";
$home_url = ""; 			//path where the script files reside in remember  with trailing slash
$site_name = "eroad";

//EDIT HERE END

/////DO NOT EDIT BELOW

// Forbinder til MySQL-serveren
$db = mysql_connect($dbserver, $username, $password);

// V�lger databasen
mysql_select_db($database,$db);

function friendlyURL($string){
	$string = preg_replace("`\[.*\]`U","",$string);
	$string = preg_replace('`&(amp;)?#?[a-z0-9]+;`i','-',$string);
	$string = htmlentities($string, ENT_COMPAT, 'utf-8');
	$string = preg_replace( "`&([a-z])(acute|uml|circ|grave|ring|cedil|slash|tilde|caron|lig|quot|rsquo);`i","\\1", $string );
	$string = preg_replace( array("`[^a-z0-9]`i","`[-]+`") , "-", $string);
	return strtolower(trim($string, '-'));
}
?>
