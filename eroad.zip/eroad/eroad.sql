-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 03, 2020 at 07:37 AM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `eroad`
--

-- --------------------------------------------------------

--
-- Table structure for table `feesmaster`
--

CREATE TABLE IF NOT EXISTS `feesmaster` (
`id` int(11) NOT NULL,
  `category` varchar(200) NOT NULL,
  `useofvehicle` varchar(200) NOT NULL,
  `typeofvehicle` varchar(300) NOT NULL,
  `fees` decimal(18,2) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feesmaster`
--

INSERT INTO `feesmaster` (`id`, `category`, `useofvehicle`, `typeofvehicle`, `fees`) VALUES
(15, 'Vehicle Licence', 'Private', 'Motorcycle/Tricycle', '100.00'),
(16, 'Road Worthiness', 'Private', 'Motorcycle/Tricycle', '200.00'),
(17, 'Insurance', 'Private', 'Motorcycle/Tricycle', '300.00'),
(18, 'Hackney Permit', 'Private', 'Motorcycle/Tricycle', '400.00');

-- --------------------------------------------------------

--
-- Table structure for table `generatepin`
--

CREATE TABLE IF NOT EXISTS `generatepin` (
`id` int(11) NOT NULL,
  `pin` varchar(300) NOT NULL,
  `useofvehicle` varchar(100) NOT NULL,
  `category` varchar(100) NOT NULL,
  `isused` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `generatepin`
--

INSERT INTO `generatepin` (`id`, `pin`, `useofvehicle`, `category`, `isused`) VALUES
(1, '1', 'Private', 'VL+RW+IN', 0),
(2, '2', 'Private', 'VL+RW+IN', 0),
(3, '3', 'Private', 'VL+RW+IN', 0),
(4, '4', 'Private', 'VL+RW+IN', 0),
(5, '5', 'Private', 'VL+RW+IN', 0),
(6, '6', 'Private', 'VL+RW+IN', 0),
(7, '7', 'Private', 'VL+RW+IN', 0),
(8, '8', 'Private', 'VL+RW+IN', 0),
(9, '9', 'Private', 'VL+RW+IN', 0),
(10, '10', 'Private', 'VL+RW+IN', 0),
(11, '11', 'Private', 'VL+RW+IN', 1);

-- --------------------------------------------------------

--
-- Table structure for table `preregistration`
--

CREATE TABLE IF NOT EXISTS `preregistration` (
`id` int(11) NOT NULL,
  `PreRegistrationNo` varchar(300) NOT NULL,
  `IsUsed` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `preregistration`
--

INSERT INTO `preregistration` (`id`, `PreRegistrationNo`, `IsUsed`) VALUES
(3, '12', 0),
(4, '13', 0),
(5, '14', 0),
(6, '22', 0),
(7, '1', 1);

-- --------------------------------------------------------

--
-- Table structure for table `registrationtypesofpayment`
--

CREATE TABLE IF NOT EXISTS `registrationtypesofpayment` (
`id` int(11) NOT NULL,
  `reg_id` int(11) NOT NULL,
  `registrationno` varchar(100) NOT NULL,
  `useofvehicle` varchar(500) NOT NULL,
  `typeofvehicle` varchar(500) NOT NULL,
  `typesofpayment` varchar(500) NOT NULL,
  `amount` decimal(18,2) NOT NULL,
  `registrationdate` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registrationtypesofpayment`
--

INSERT INTO `registrationtypesofpayment` (`id`, `reg_id`, `registrationno`, `useofvehicle`, `typeofvehicle`, `typesofpayment`, `amount`, `registrationdate`) VALUES
(1, 1, '1', 'Private', 'Motorcycle/Tricycle', 'Vehicle Licence', '100.00', '2020-03-03'),
(2, 1, '1', 'Private', 'Motorcycle/Tricycle', 'Road Worthiness', '200.00', '2020-03-03'),
(3, 1, '1', 'Private', 'Motorcycle/Tricycle', 'Hackney Permit', '400.00', '2020-03-03'),
(4, 1, '1', 'Private', 'Motorcycle/Tricycle', 'Insurance', '300.00', '2020-03-03');

-- --------------------------------------------------------

--
-- Table structure for table `renewal`
--

CREATE TABLE IF NOT EXISTS `renewal` (
`id` int(11) NOT NULL,
  `registrationdate` varchar(200) DEFAULT NULL,
  `duedate` varchar(200) DEFAULT NULL,
  `registrationno` varchar(100) DEFAULT NULL,
  `name` varchar(300) DEFAULT NULL,
  `address` text,
  `phonenumber` varchar(50) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `useofvehicle` varchar(100) DEFAULT NULL,
  `typeofvehicle` varchar(100) DEFAULT NULL,
  `paymentoption` varchar(100) DEFAULT NULL,
  `pinnumber` varchar(100) DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `receiptno` int(7) NOT NULL DEFAULT '0',
  `chassissno` varchar(1000) NOT NULL,
  `typesofpayment` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `renewaltypesofpayment`
--

CREATE TABLE IF NOT EXISTS `renewaltypesofpayment` (
`id` int(11) NOT NULL,
  `reg_id` int(11) NOT NULL,
  `registrationno` varchar(100) NOT NULL,
  `useofvehicle` varchar(500) NOT NULL,
  `typeofvehicle` varchar(500) NOT NULL,
  `typesofpayment` varchar(500) NOT NULL,
  `amount` decimal(18,2) NOT NULL,
  `registrationdate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `usermaster`
--

CREATE TABLE IF NOT EXISTS `usermaster` (
`SrNo` int(11) NOT NULL,
  `firstname` varchar(200) NOT NULL,
  `lastname` varchar(200) NOT NULL,
  `contactno` varchar(50) NOT NULL,
  `UserName` varchar(200) NOT NULL,
  `Password` text NOT NULL,
  `email` varchar(100) NOT NULL,
  `usertype` varchar(200) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usermaster`
--

INSERT INTO `usermaster` (`SrNo`, `firstname`, `lastname`, `contactno`, `UserName`, `Password`, `email`, `usertype`) VALUES
(6, 'bhavin1', 'kevadiya', '9909334868', 'bhavin', 'de6b0c87d96dffad0b8b4deb59060d07', 'nameisbhavin69@gmail.com', 'Super Admin'),
(9, 'amit', 'dholiya', '9909334868', 'amit', '0cb1eb413b8f7cee17701a37a1d74dc3', 'amit@yopmail.com', '2');

-- --------------------------------------------------------

--
-- Table structure for table `vehiclelicense`
--

CREATE TABLE IF NOT EXISTS `vehiclelicense` (
`id` int(11) NOT NULL,
  `registrationdate` varchar(200) DEFAULT NULL,
  `duedate` varchar(200) DEFAULT NULL,
  `registrationno` varchar(100) DEFAULT NULL,
  `name` varchar(300) DEFAULT NULL,
  `address` text,
  `phonenumber` varchar(50) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `useofvehicle` varchar(100) DEFAULT NULL,
  `typeofvehicle` varchar(100) DEFAULT NULL,
  `paymentoption` varchar(100) DEFAULT NULL,
  `pinnumber` varchar(100) DEFAULT NULL,
  `amount` decimal(15,2) DEFAULT NULL,
  `receiptno` int(7) NOT NULL DEFAULT '0',
  `chassissno` varchar(1000) NOT NULL,
  `typesofpayment` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vehiclelicense`
--

INSERT INTO `vehiclelicense` (`id`, `registrationdate`, `duedate`, `registrationno`, `name`, `address`, `phonenumber`, `email`, `useofvehicle`, `typeofvehicle`, `paymentoption`, `pinnumber`, `amount`, `receiptno`, `chassissno`, `typesofpayment`) VALUES
(1, '2020-03-03', '2021-03-04', '1', 'bhavin kevadiya', '3033,silver business point,near vip circle, mota varachha,surat', '9909334868', 'nameisbhavin69@gmail.com', 'Private', 'Motorcycle/Tricycle', 'PIN', '11', '1000.00', 0, '1234', 'Vehicle Licence,Road Worthiness,Hackney Permit,Insurance');

-- --------------------------------------------------------

--
-- Table structure for table `vehiclelicensedetails`
--

CREATE TABLE IF NOT EXISTS `vehiclelicensedetails` (
`id` int(11) NOT NULL,
  `registrationdate` varchar(100) NOT NULL,
  `duedate` varchar(100) NOT NULL,
  `registrationno` varchar(500) NOT NULL,
  `paymentoption` varchar(200) NOT NULL,
  `pinnumber` varchar(500) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `isnew` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vehiclelicensedetails`
--

INSERT INTO `vehiclelicensedetails` (`id`, `registrationdate`, `duedate`, `registrationno`, `paymentoption`, `pinnumber`, `amount`, `isnew`) VALUES
(1, '2020-03-03', '2021-03-04', '1', 'PIN', '11', '1000.00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `vehiclelicense_receiptno`
--

CREATE TABLE IF NOT EXISTS `vehiclelicense_receiptno` (
`receiptno` int(7) unsigned zerofill NOT NULL,
  `registrationno` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vehiclelicense_receiptno`
--

INSERT INTO `vehiclelicense_receiptno` (`receiptno`, `registrationno`) VALUES
(0000001, 'EP-123456789'),
(0000002, '12'),
(0000003, '12'),
(0000004, '12'),
(0000005, '12'),
(0000006, '13'),
(0000007, '14'),
(0000008, '12'),
(0000009, '22'),
(0000010, '1'),
(0000011, '1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `feesmaster`
--
ALTER TABLE `feesmaster`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `generatepin`
--
ALTER TABLE `generatepin`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `preregistration`
--
ALTER TABLE `preregistration`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registrationtypesofpayment`
--
ALTER TABLE `registrationtypesofpayment`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `renewal`
--
ALTER TABLE `renewal`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `renewaltypesofpayment`
--
ALTER TABLE `renewaltypesofpayment`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `usermaster`
--
ALTER TABLE `usermaster`
 ADD PRIMARY KEY (`SrNo`);

--
-- Indexes for table `vehiclelicense`
--
ALTER TABLE `vehiclelicense`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vehiclelicensedetails`
--
ALTER TABLE `vehiclelicensedetails`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vehiclelicense_receiptno`
--
ALTER TABLE `vehiclelicense_receiptno`
 ADD PRIMARY KEY (`receiptno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `feesmaster`
--
ALTER TABLE `feesmaster`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `generatepin`
--
ALTER TABLE `generatepin`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `preregistration`
--
ALTER TABLE `preregistration`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `registrationtypesofpayment`
--
ALTER TABLE `registrationtypesofpayment`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `renewal`
--
ALTER TABLE `renewal`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `renewaltypesofpayment`
--
ALTER TABLE `renewaltypesofpayment`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `usermaster`
--
ALTER TABLE `usermaster`
MODIFY `SrNo` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `vehiclelicense`
--
ALTER TABLE `vehiclelicense`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `vehiclelicensedetails`
--
ALTER TABLE `vehiclelicensedetails`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `vehiclelicense_receiptno`
--
ALTER TABLE `vehiclelicense_receiptno`
MODIFY `receiptno` int(7) unsigned zerofill NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
