<?php


include 'dbconfig.php';
?>
<!DOCTYPE html>
<html class="no-js" lang="zxx">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="eROAD">
  <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">

  <title>eRoad| The easiest payment for Road User</title>
<!--


-->

  <!-- Additional CSS Files -->
  <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">

  <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.css">

  <link rel="stylesheet" href="assets/css/eroad.css">
    <link rel="stylesheet" href="assets/js/bootstrap.min.js">
      <link rel="stylesheet" href="assets/js/jquery.counterup.min.js">
      <link rel="stylesheet" href="assets/js/imgfix.min.js">
        <link rel="stylesheet" href="assets/js/jquery-2.1.0.min.js">
        <link rel="stylesheet" href="assets/js/custom.js">
        <link rel="stylesheet" href="admin/js/datatable-basic.js">
        <link rel="stylesheet" href="admin/js/datatables.min.js">
  <link rel="stylesheet" href="assets/css/owl-carousel.css">
    <link rel="stylesheet" href="admin/app-assets/css/custom/custom.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/themes/vertical-modern-menu-template/materialize.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/themes/vertical-modern-menu-template/style.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/pages/dashboard-modern.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/pages/intro.min.css">
      <link rel="stylesheet" href="admin/app-assets/css/pages/register.min.css">
    <link rel="shortcut icon" href="assets/images/favicon.ico" type="image/x-icon" />
    <link rel="stylesheet" type="text/css" href="app-assets/vendors/data-tables/css/jquery.dataTables.min.css">
   <link rel="stylesheet" type="text/css" href="app-assets/vendors/data-tables/extensions/responsive/css/responsive.dataTables.min.css">
   <link rel="stylesheet" type="text/css" href="app-assets/vendors/data-tables/css/select.dataTables.min.css">


</head>

<body class="loader-active">

    <!--== Preloader Area Start ==-->
    <div class="preloader">
      <div id="preloader">
          <div class="jumper">
              <div></div>
              <div></div>
              <div></div>
          </div>
      </div>
    <!--== Preloader Area End ==-->

    <!--== Header Area Start ==-->
    <header class="header-area header-sticky">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <nav class="main-nav">
                        <!-- ***** Logo Start ***** -->
                        <a href="index.html" class="logo">
                              <img src="assets/images/logo.png" alt="">
                        </a>
                        <!-- ***** Logo End ***** -->
                        <!-- ***** Menu Start ***** -->
                        <ul class="nav">
                            <li class="scroll-to-section"><a href="index.html" class="">Home</a></li>
                            <li class="scroll-to-section"><a href="#" class="">About</a></li>
                            <li class="scroll-to-section"><a href="#" class="">Services</a>
                            </li>
                            <li class="scroll-to-section"><a href="#apply" class="menu-item">Apply</a>
                            </li>
                            <li class="scroll-to-section"><a href="#contact-us" class="menu-item">Contact Us</a></li>
                        </ul>
                        <a class='menu-trigger'>
                            <span>Menu</span>
                        </a>
                        <!-- ***** Menu End ***** -->
                    </nav>
                </div>
            </div>
        </div>
    </header>
        <!--== Header Top End ==-->


<!-- BEGIN: Page Main-->

    <!--== Page Title Area Start ==-->
    <!--== Page Title Area End ==-->
  <section class="section" id="about">
    <div class="contact-page-wrao section-padding">
        <div class="container">
          <div class="row">
              <div class="col-lg-8 offset-lg-2">
                  <div class="center-heading">
          <h2>Vehicle </h2>
          <p>Document Registration</p>
        </div>
        </div>
        </div>

  <div class="row">


 <?php
if (!isset($_GET['cmd']))
{
$_GET['cmd'] = "";
}
if($_GET["cmd"]=="success")
{
date_default_timezone_set('Africa/Lagos');
$dt=date("Y-m-d");
$name=$_GET['name'];
$registrationdate=$_GET['registrationdate'];
$registrationno=$_GET['registrationno'];

$address=$_GET['address'];
$phonenumber=$_GET['phonenumber'];
$email=$_GET['email'];
$useofvehicle=$_GET['useofvehicle'];
$typeofvehicle=$_GET['typeofvehicle'];
$paymentoption=$_GET['paymentoption'];
$pinnumber=$_GET['pinnumber'];
$amount=$_GET['amount'];
$duedate=$_GET['duedate'];
$chassissno=$_GET['chassissno'];
$typesofpayment=$_GET['typesofpayment'];


//print_r($typesofpayment);exit();

$date = str_replace('/', '-', $duedate );
$duedate1 = date("Y-m-d", strtotime($date));


	$sql2="INSERT INTO vehiclelicense (name,registrationdate,registrationno,address,phonenumber,email,useofvehicle,typeofvehicle,paymentoption,pinnumber,amount,duedate,chassissno,typesofpayment)
VALUES ('$name','$registrationdate','$registrationno','$address','$phonenumber','$email','$useofvehicle','$typeofvehicle','$paymentoption','$pinnumber','$amount','$duedate1','$chassissno','$typesofpayment')";
//print_r($sql2);
$result2 = mysql_query($sql2);
$last_id=mysql_insert_id();

$typesofpayment=explode(",",$typesofpayment);
foreach($typesofpayment as $value){
  $GetPhotoSQL ="SELECT fees FROM feesmaster WHERE category = '$value' and useofvehicle='$useofvehicle'
  and typeofvehicle='$typeofvehicle'";
  $GetPhotoResult = mysql_query($GetPhotoSQL);
  $GetPhotoRow = mysql_fetch_array($GetPhotoResult);

  //echo $GetPhotoRow['fees'];
  $fees=$GetPhotoRow['fees'];
  $sql2="INSERT INTO registrationtypesofpayment (reg_id,registrationno,useofvehicle,typeofvehicle,typesofpayment
  ,amount,registrationdate)
VALUES ('$last_id','$registrationno','$useofvehicle','$typeofvehicle','$value','$fees',
'$registrationdate')";
//print_r($sql2);
$result2 = mysql_query($sql2);

}
//exit();
	$sql4="INSERT INTO vehiclelicensedetails (registrationdate,duedate,registrationno,paymentoption,pinnumber,amount)
VALUES ('$registrationdate','$duedate1','$registrationno','$paymentoption','$pinnumber','$amount')";
//print_r($sql4);
$result4 = mysql_query($sql4);


$sql3="update preregistration set IsUsed='1' WHERE PreRegistrationNo='$registrationno'";
//print_r($sql3);
$result3 = mysql_query($sql3);
if($pinnumber!='')
{
$sql4="update generatepin set isused='1' WHERE pin='$pinnumber'";
//print_r($sql3);
$result4 = mysql_query($sql4);
}

$sql5="INSERT INTO vehiclelicense_receiptno (registrationno)
VALUES ('$registrationno')";
$result4 = mysql_query($sql5);

/*require('textlocal.class.php');
$textlocal = new Textlocal('bekinsmart@gmail.com', '5D7kAMyB86CJGg*');
$numbers = array($phonenumber);
$sender = 'EasyTax';
$message = 'Congratulation! Vehicle Registration for {$registrationno} successful
valid till {$duedate1}. Your Vehicle Documents will be made available soonest';
$result = $textlocal->sendSms($numbers, $message, $sender);*/

?>
<!-- <script> window.open("Receipt/vehiclelicense.php?registrationno=<?php Print $registrationno;?>"); </script>  -->
<!-- <script> location.replace("registration.php?status=success"); </script> -->
<script> location.replace("thankyou.php?status=registration&amount=<?php Print $amount;?>&pmode=<?php Print $paymentoption;?>"); </script>

<!-- <script> location.replace("thankyou.php?status=registration&registrationno=<?php Print $registrationno;?>"); </script> -->

 <?php
 }
if (!isset($_GET['status']))
{
$_GET['status'] = "";
}
if($_GET["status"]=="success")
{
?>

<div class="card-alert card gradient-45deg-green-teal">
    <div class="card-content white-text">
      <p>
         <i class="material-icons">check</i> Vehicle Registration Successful
      </p>
    </div>
</div>

<?php
}

?>


                <div class="col-lg-12 m-auto">
                    <div class="contact-form">
                        <form method="post" action="pay.php">
                            <div class="row">
                                <div class="col-lg-6 col-md-6">
                                    <div class="name-input">
                                         <input placeholder="Placeholder" id="date"  type="date" name="registrationdate" onchange="getdate()" required=""
                            max="<?php echo date('Y-m-d'); ?>" min="<?php echo date('Y-m-d'); ?>">
                                    </div>
                                </div>

                                <div class="col-lg-6 col-md-6" style="visibility: hidden;">

                                        <select  name="registrationno" class="sl" >
                              <option value="" disabled selected>Choose your option</option>
                             <?php
                              $query4="SELECT * FROM preregistration where IsUsed=0 ORDER BY id ASC";
                              $result4=mysql_query($query4);
                              $num4=mysql_numrows($result4);
                              $iiii=0;
                              while ($iiii < $num4) {

                              $projects_id4=mysql_result($result4,$iiii,"PreRegistrationNo");
                              $projects_name4=mysql_result($result4,$iiii,"PreRegistrationNo");

                              ?>

                              <option value="<?php echo $projects_id4; ?>"><?php echo $projects_name4; ?></option>
                              <?php
                              $iiii++;
                              }
                              ?>
                            </select>

                                </div>
                            </div>

                            <div class="row">
                                <div class="col-lg-6 col-md-6">
                                    <div class="website-input">
                                        <input id="password" type="text" name="name" placeholder="Name of Owner" required="">
                                    </div>
                                </div>

                                <div class="col-lg-6 col-md-6">
                                    <div class="subject-input">
                                    	<input id="email3" type="text" placeholder="Phone No of Owner"  name="phonenumber" required="">

                                    </div>
                                </div>
                            </div>

                            <div class="message-input">
                                <textarea id="icon_prefix2" placeholder="Address of Owner" name="address" required="" class="materialize-textarea" ></textarea>
                            </div>

                             <div class="row">
                                <div class="col-lg-6 col-md-6">
                                    <div class="website-input">
                                       <input id="password" type="email" placeholder="Email" name="email" required="">
                                    </div>
                                </div>

                                <div class="col-lg-6 col-md-6">
                                    <div class="subject-input">
                                    	<input onblur="check_chassiss()" placeholder="Chassiss No" id="chassiss" type="text" required="" name="chassissno">
                                    	<div style="color:red;font-size:20px;" id="chassissno" class="chassissno"></div>

                                    </div>
                                </div>
                            </div>


                             <div class="row">
                                <div class="col-lg-4 col-md-4">
                                    <div class="website-input">
                                               <select id="useofvehicle" name="useofvehicle" onchange="getdate()" required="" style="width: 100%;background-color: #fafafa;border: 1px solid #eaeaea;color: #000;padding: 8px 15px;">
                            <option value="" disabled selected>Choose your option</option>

                          <option value="Private">Private</option>
                          <option value="Commercial">Commercial</option>
                          </select>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-4">
                                     <div class="website-input">
                                    	<select id="typeofvehicle" name="typeofvehicle" required=""style="width: 100%;background-color: #fafafa;border: 1px solid #eaeaea;color: #000;padding: 8px 15px;">
                            <option value="" disabled selected>Choose your option</option>

                          <option value="Motorcycle/Tricycle">Motorcycle/Tricycle</option>
                          <option value="Car">Car</option>
                          <option value="Bus/SUV/Jeep">Bus/SUV/Jeep</option>
                         <option value="Tipper/Trailer">Tipper/Trailer</option>

                          </select>

                                    </div>
                                </div>
                            
                                <div class="col-lg-4 col-md-4">
                                    <div class="website-input">
                                        <input  type="text" name="duedate" placeholder="Expiry Date" id="duedate" readonly="">
                                    </div>
                                </div>
                            </div>

                             <div class="row">
                                <div class="col-lg-12 col-md-12">
                                
                                    <div id="view-checkboxes" style="text-align: left;">
                          <label for="payment" style="color:#6d6969;font-weight: bold;">Type of Payment</label>
                          <div class="input-field col s12">
                            <p class="mb-1">
                              <label>
                                <input class="payment" type="checkbox" value="Vehicle Licence" id="payment1" name="typesofpayment[]" />
                                <span>Vehicle Licence</span>
                              </label>
                            </p>
                            <p class="mb-1">
                              <label>
                                <input class="payment" type="checkbox" value="Road Worthiness" id="payment2" name="typesofpayment[]" />
                                <span>Road Worthiness</span>
                              </label>
                            </p>
                            <p class="mb-1">
                              <label>
                                <input class="payment" type="checkbox" value="Hackney Permit"  id="payment3" name="typesofpayment[]"/>
                                <span>Hackney Permit</span>
                              </label>
                            </p>
                            <p class="mb-1">
                              <label>
                                <input class="payment" type="checkbox" value="Insurance" id="payment4" name="typesofpayment[]" />
                                <span>Insurance </span>
                              </label>
                            </p>
                             <p class="mb-1">
                              <label>
                                <input class="payment" type="checkbox" value="Tipper/Trailer Permit" id="payment5" name="typesofpayment[]" />
                                <span>Tipper/Trailer Permit </span>
                              </label>
                            </p>
                            <p class="mb-1">
                              <label>
                                <input class="payment" type="checkbox" value="Number Plate" id="payment6" name="typesofpayment[]" />
                                <span>Number Plate </span>
                              </label>
                            </p>
                          </div>
                        </div>
                                </div>
                            </div>



                            <div class="row">
                                <div class="col-lg-4 col-md-4">
                                    <div class="website-input">
                                       <select id="paymenttype" onchange="checkFilled();" name="paymentoption" required=""style="width: 100%;background-color: #fafafa;border: 1px solid #eaeaea;color: #000;padding: 8px 15px;">
                            <option value="" disabled selected>Choose your option</option>
                              <option value="Online">Online</option>
                              <option value="PIN">PIN</option>
                          </select>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-4">
                                    <div class="subject-input">
                                    	<input onblur="check_pin()" placeholder="PIN Number" type="text" class="form-control" name="pinnumber" id="pin"
                              placeholder="PIN Number " readonly >
                             <div style="color:red;font-size:20px;" id="uname_response" class="response"></div>

                                    </div>
                                </div>



                            	       <div class="col-lg-4 col-md-4">
                                    <div class="subject-input">
                                    	<input id="amount" type="text" placeholder="Amount" name="registrationfee" required="" readonly="">
                                    </div>
                                </div>
                      </div>




                            <div class="input-submit">

                                 <button type="submit" id="form-submit" class="main-button">Register

                            </div>
                        </form>
                    </div>
                </div>

  </div>
</div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
      </section>
<script>
    $(document).ready(function() {

      $('#useofvehicle').on('change',function(){
    var useofvehicle = $(this).val();
    var typeofvehicle=$("#typeofvehicle").val();// value in field email
    var payment_type = [];
            $.each($("input[class='payment']:checked"), function(){
                payment_type.push("'"+$(this).val()+"'");
            });
            if(payment_type.length!=0){ payment_type=payment_type}else { payment_type="'Prime'";}
    $.ajax({
     type :'GET',
        dataType:'json',
    data:{useofvehicle: useofvehicle,typeofvehicle: typeofvehicle,paymenttype:payment_type},
        url : 'codegenrate.php?useofvehicle='+useofvehicle+'&typeofvehicle='+typeofvehicle+'&paymenttype='+payment_type,
        success : function(result){
    $('#amount').val(result['fees']);
    }
   });
  });

  $(".payment").click(function(){
    //alert();
        var useofvehicle =$("#useofvehicle").val();// value in field email
        var typeofvehicle=$("#typeofvehicle").val();// value in field email
        var payment_type = [];
        $.each($("input[class='payment']:checked"), function(){
            payment_type.push("'"+$(this).val()+"'");
        });
        if(payment_type.length!=0){ payment_type=payment_type}else { payment_type="'Prime'";}
          $.ajax({
         type :'GET',
            dataType:'json',
           url : 'codegenrate.php?useofvehicle='+useofvehicle+'&typeofvehicle='+typeofvehicle+'&paymenttype='+payment_type,
            success : function(result){
            $('#amount').val(result['fees']);
            M.updateTextFields();
        }
        });
  });


  $('#typeofvehicle').on('change',function(){
  var typeofvehicle = $(this).val();
  var useofvehicle=$("#useofvehicle").val();// value in field email
  var payment_type = [];
        $.each($("input[class='payment']:checked"), function(){
            payment_type.push("'"+$(this).val()+"'");
        });
        if(payment_type.length!=0){ payment_type=payment_type}else { payment_type="'Prime'";}
  $.ajax({
   type :'GET',
      dataType:'json',
 // data:{country_id: countryID,typeofvehicle: typeofvehicle,category:category},
     url : 'codegenrate.php?useofvehicle='+useofvehicle+'&typeofvehicle='+typeofvehicle+'&paymenttype='+payment_type,
      success : function(result){
  $('#amount').val(result['fees']);
  }

  });
  });


    });
</script>



<script>
$(document).ready(function(){
    $('#paymenttype').on('change',function(){
        var paymenttype = $(this).val();
    if(paymenttype=="Online")
  {
     $('#pin').prop('required', false);
    document.getElementById("pin").readOnly = true;
  }
  else
  {
    $('#pin').prop('required', true);
  document.getElementById("pin").readOnly = false;
  }
    });
 });
function getdate() {
var tt1 = document.getElementById('useofvehicle').value;
if(tt1=='Private')
{
    var tt = document.getElementById('date').value;
    //alert(tt);
    var date = new Date(tt);
//alert(date);
    var newdate = new Date(date);
    newdate.setDate(newdate.getDate() + 366);
    var dd = newdate.getDate();
    var mm = newdate.getMonth() + 1;
    var y = newdate.getFullYear();
   // alert(newdate);
    var someFormattedDate = dd + '/' + mm + '/' + y;
    document.getElementById('duedate').value = someFormattedDate;
    M.updateTextFields();
  //$('select').formSelect();
}
else if(tt1=='Commercial')
{
    var tt = document.getElementById('date').value;
    var date = new Date(tt);
    var newdate = new Date(date);
    newdate.setDate(newdate.getDate() + 183);
    var dd = newdate.getDate();
    var mm = newdate.getMonth() + 1;
    var y = newdate.getFullYear();
    var someFormattedDate = dd + '/' + mm + '/' + y;
    document.getElementById('duedate').value = someFormattedDate;
}
}
</script>
<script type="text/javascript">
function check_pin(){

var pin=$("#pin").val();// value in field email
var useofvehicle=document.getElementById('useofvehicle').value;
var paymenttype=document.getElementById('paymenttype').value;
//alert(paymenttype);
if(paymenttype=='PIN')
{

$.ajax({
    type:'GET',
     url : 'checkpinexists.php?pin='+pin+'&useofvehicle='+useofvehicle,
     // url:'checkpinexists.php',// put your real file name
        //data:{pin: pin},
    //data:{pin: pin,useofvehicle: useofvehicle},
        success:function(msg){
    if(msg>0)
    {
     $("#uname_response").hide();
    }
    else
    {
     $("#uname_response").show();
     $("#uname_response").html("<span class='not-exists'>* PIN Not Available.</span>");
         //alert(msg); // your message will come here.
     $('#pin').val(''); //txtID is textbox ID
    // $("#pin").focus();
    }
        }
 });
}
}
</script>
<script>
function validateForm() {
var paymentoption=document.forms["myForm"]["paymentoption"].value;
if(paymentoption=='PIN')
{
  var x = document.forms["myForm"]["pinnumber"].value;
  if (x == "") {
    alert("Please Enter PIN");
  $('#pin').val(''); //txtID is textbox ID
  //$("#pin").focus();
    return false;
  }
  }
}
</script>


<script type="text/javascript">
function check_chassiss(){

var chassissno=$("#chassiss").val();// value in field email

$.ajax({
    type:'GET',
     url : 'checkchassissnoexists.php?chassissno='+chassissno,
     // url:'checkpinexists.php',// put your real file name
        //data:{pin: pin},
    //data:{pin: pin,useofvehicle: useofvehicle},
        success:function(msg){
    if(msg>0)
    {
       $("#chassissno").show();
       $("#chassissno").html("<span class='not-exists'>* Chassiss No All Ready Exists.</span>");
       $('#chassiss').val(''); //txtID is textbox ID
    }
    else
    {
     $("#chassissno").hide();
    // $("#pin").focus();
    }
        }
 });
}
</script>
<!-- END: Page Main-->
<!-- ***** Footer Start ***** -->
<footer id="contact-us">
    <div class="container">
        <div class="footer-content">
            <div class="row">
                <!-- ***** Contact Form Start ***** -->
                <div class="col-lg-6 col-md-12 col-sm-12">
                    <div class="contact-form">
                        <form id="contact" action="" method="post">
                            <div class="row">
                                <div class="col-md-6 col-sm-12">
                                    <fieldset>
                                        <input name="name" type="text" id="name" placeholder="Full Name" required=""
                                            style="background-color: rgba(250,250,250,0.3);">
                                    </fieldset>
                                </div>
                                <div class="col-md-6 col-sm-12">
                                    <fieldset>
                                        <input name="email" type="text" id="email" placeholder="E-Mail Address"
                                            required="" style="background-color: rgba(250,250,250,0.3);">
                                    </fieldset>
                                </div>
                                <div class="col-lg-12">
                                    <fieldset>
                                        <textarea name="message" rows="6" id="message" placeholder="Your Message"
                                            required="" style="background-color: rgba(250,250,250,0.3);"></textarea>
                                    </fieldset>
                                </div>
                                <div class="col-lg-12">
                                    <fieldset>
                                        <button type="submit" id="form-submit" class="main-button">Send Message
                                            Now</button>
                                    </fieldset>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- ***** Contact Form End ***** -->
                <div class="right-content col-lg-6 col-md-12 col-sm-12">
                    <h2>More About <em>eROAD</em></h2>
                    <p>eRoad solution, given you an easy and better experience to your vehicle registration,
                      anywhere any time with your mobile phone- on a dial up. Road users can register their vehicle,
                      licnce, road worthiness, hackney permit, insurrance at the comfort of thier home/office.
                        <br><br>If you need this contact form to send email to your inbox, you may follow our <a
                            rel="nofollow" href="c#" target="_parent">contact</a> page
                        for more detail.</p>
                    <ul class="social">
                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                        <li><a href="#"><i class="fa fa-rss"></i></a></li>
                        <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="sub-footer">
                    <p>Copyright &copy; 2020 eROAD by-Rizquad Technnology Limited

                    | Designed by <a rel="nofollow" href="https://renownedtechng.com">RenownedTechng</a></p>
                </div>
            </div>
        </div>
    </div>
</footer>

<!-- jQuery -->
<script src="assets/js/jquery-2.1.0.min.js"></script>

<!-- Bootstrap -->
<script src="assets/js/popper.js"></script>
<script src="assets/js/bootstrap.min.js"></script>

<!-- Plugins -->
<script src="assets/js/owl-carousel.js"></script>
<script src="assets/js/scrollreveal.min.js"></script>
<script src="assets/js/waypoints.min.js"></script>
<script src="assets/js/jquery.counterup.min.js"></script>
<script src="assets/js/imgfix.min.js"></script>

<!-- Global Init -->
<script src="assets/js/custom.js"></script>

</body>
</html>
