<?php
   use AfricasTalking\SDK\AfricasTalking;
   
   defined('BASEPATH') OR exit('No direct script access allowed');
   
   class Ussd extends CI_Controller
   {
       
       	function __construct()
   	{
   	  
   		parent::__construct();
   		
   		$this->load->library(array('form_validation','upload'));
   		$this->load->helper(array('form'));
   		$this->load->model(array('Ussd_model'));
   		$this->load->model(array('Generate_pin_model'));
   		$this->load->model(array('Membership_model'));
   	
   	}
      
       public function index()
       {
         
           // Reads the variables sent via POST from our gateway
           $sessionId   = $_POST["sessionId"];
           $serviceCode = $_POST["serviceCode"];
           $phoneNumber = $_POST["phoneNumber"];
           $text        = $_POST["text"];
           
           $finalphoneNumber = substr($phoneNumber, 4);
           
           $membership = $this->Ussd_model->get_member($finalphoneNumber);
                               
           $mytext     = str_replace('2*', '', $text); 
           $mytexts     = str_replace('3*', '', $text); 
           
           if (isset($membership) && $membership != '') {
               $membership_id     = $membership['membership_id'];
               $membership_image  = $membership['membership_image'];
               $membership_number = $membership['membership_number'];
               $full_name         = $membership['full_name'];
               $phone_number      = $membership['phone_number'];
               $gender            = $membership['gender'];
               $date_of_birth     = $membership['date_of_birth'];
               $registration_date = $membership['registration_date'];
               $expire_date       = $membership['expire_date'];
               $address           = $membership['address'];
               $designation       = $membership['designation'];
               $unit              = $membership['unit'];
               $branch            = $membership['branch'];
               $state             = $membership['state'];
               $pin               = $membership['pin'];
               $accept            = $membership['accept'];
               $fee               = $membership['fee'];
               
               $pinget = str_replace('2*'.$membership_number.'*', '', $text);
               
               if (strpos($pinget, '*')) {
                   $pinget = explode('*', $pinget);
                   $pinget = $pinget[1];
               } else {
                   $pinget = $pinget;
               }
               
             
               $pin_exist = $this->Generate_pin_model->verified_pin($pinget);
           
           
           if ($text == "") {
           // This is the first request. Note how we start the response with CON
               $response = "CON Welcome to Vehicle EROAD \n";
               $response .= "1. Registration \n";
               $response .= "2. Renewal \n";
               $response .= "3. Status Check";
               } 
               else if ($text == "1") {
                   $response = "CON Vehicle Registration \n";
                   $response .= "1.Visit (www.eroad.ng) to register \n";
                   $response .= "2. Back";
               }
                 else if($text == "1*1") { 
                   $response = "CON Your Link is \n";
                   $response = "END Your Registration Link is www.eroad.ng";
               }
               
               else if ($text == "1*2") {
                   $response = "CON Welcome to Vehicle Eroad \n";
                   $response .= "1. Registration \n";
                   $response .= "2. Renewal \n";
                   $response .= "3. Status Check";
               }
               
               else if ($text == "2") {
                   $response = "CON Vehicle Renewal \n";
                   $response .= "1. Enter VehID";
               }
               else if($mytext == $membership_number){
                                       $response = "CON Enter PIN";
               }
    
               else if($pin_exist == 1)
               {
                        $this->Registration_model->update_registration(array('expire_date' => trim(date("Y-m-d",strtotime("+1 years")))),$membership_id);
                        $response = 'END Membership Renew successfully!'; 
               }

               else if ($mytexts == "3") {
                   $response = "CON Status Checker \n";
                   $response .= "Enter VehID";
               } 
             else if($mytexts == $registration_number){
                  $response = "END Your Registration Validity : ".$expire_date;
               }
           
   
   // Echo the response back to the API
   header('Content-type: text/plain');
   echo $response;
           }
           
       }
   }
   ?>